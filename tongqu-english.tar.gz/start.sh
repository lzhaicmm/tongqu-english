#!/bin/bash
# =======================================================
#  🎓 童趣英语 - 一键启动脚本 (Mac / Linux)
# =======================================================
#  用法 1 (推荐):  双击 start.command
#  用法 2:         终端执行  bash start.sh
# =======================================================

set -e

# 颜色
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

# 切到脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║     🎓  童趣英语 - 少儿英语学习平台      ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"
echo ""

# 1️⃣ 检查 Node.js
echo -e "${YELLOW}[1/4] 检查 Node.js 环境...${NC}"
if ! command -v node &> /dev/null; then
  echo -e "${RED}❌ 未检测到 Node.js！${NC}"
  echo -e "${YELLOW}👉 请先去 https://nodejs.org/zh-cn 下载安装 Node.js 18+${NC}"
  echo ""
  read -p "按回车关闭..."
  exit 1
fi
NODE_VER=$(node -v)
echo -e "   ✅ Node.js: ${GREEN}$NODE_VER${NC}"

# 检查版本是否 >= 18
NODE_MAJOR=$(echo "$NODE_VER" | sed 's/v//' | cut -d. -f1)
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo -e "${RED}❌ Node.js 版本过低（需要 18+，当前 $NODE_VER）${NC}"
  echo -e "${YELLOW}👉 请升级 https://nodejs.org/zh-cn${NC}"
  read -p "按回车关闭..."
  exit 1
fi

# 2️⃣ 换国内镜像（加速）
if ! grep -q "npmmirror" ~/.npmrc 2>/dev/null; then
  echo -e "${YELLOW}[2/4] 配置国内 npm 镜像源（加速下载）...${NC}"
  npm config set registry https://registry.npmmirror.com
  echo -e "   ✅ 已切换到 npmmirror"
else
  echo -e "${YELLOW}[2/4] npm 镜像已配置，跳过${NC}"
fi

# 3️⃣ 安装依赖（首次运行才需要）
if [ ! -d "node_modules" ]; then
  echo -e "${YELLOW}[3/4] 首次运行，正在安装依赖（约 1-3 分钟）...${NC}"
  npm install
  if [ $? -ne 0 ]; then
    echo -e "${RED}❌ 依赖安装失败！${NC}"
    echo -e "${YELLOW}👉 尝试手动执行: npm install --registry https://registry.npmmirror.com${NC}"
    read -p "按回车关闭..."
    exit 1
  fi
  echo -e "   ✅ 依赖安装完成"
else
  echo -e "${YELLOW}[3/4] node_modules 已存在，跳过安装${NC}"
fi

# 4️⃣ 清理占用 5173 的旧进程
PORT=5173
if command -v lsof &> /dev/null; then
  OLD_PID=$(lsof -ti :$PORT 2>/dev/null || true)
  if [ -n "$OLD_PID" ]; then
    echo -e "${YELLOW}   ⚠️  端口 $PORT 被占用 (PID: $OLD_PID)，正在释放...${NC}"
    kill $OLD_PID 2>/dev/null || true
    sleep 1
  fi
fi

# 启动开发服务器
echo ""
echo -e "${GREEN}══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}  🚀  启动成功！请打开浏览器访问：${NC}"
echo -e "${GREEN}  ${CYAN}http://localhost:5173${NC}"
echo -e "${GREEN}══════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}🔑  登录账号：demo@kids.com / 123456${NC}"
echo -e "${YELLOW}💡  口语对话入口：http://localhost:5173/conversation${NC}"
echo ""
echo -e "${YELLOW}⚠️  关闭此终端窗口即可停止服务${NC}"
echo ""

npm run dev
