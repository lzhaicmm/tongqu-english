// 用户类型
export interface User {
  id: string;
  username: string;
  email: string;
  password: string;
  avatar: string;
  grade: string; // 年级
  level: number; // 等级
  exp: number;   // 经验值
  coins: number; // 金币
  streakDays: number; // 连续学习天数
  lastLoginDate: string;
  joinedAt: string;
}

// 课程分级
export type CourseLevel = 'starter' | 'elementary' | 'intermediate' | 'advanced';

export interface Course {
  id: string;
  title: string;
  description: string;
  level: CourseLevel;
  gradeRange: string; // 适用年级，如 "1-2年级"
  icon: string;
  color: string;
  totalLessons: number;
  estimatedHours: number;
  rating: number;
  studentsCount: number;
  lessons: Lesson[];
}

// 课时
export interface Lesson {
  id: string;
  courseId: string;
  title: string;
  order: number;
  type: 'vocabulary' | 'grammar' | 'speaking' | 'listening';
  duration: number; // 分钟
  isFree: boolean;
}

// 学习记录
export interface LearningRecord {
  userId: string;
  lessonId: string;
  courseId: string;
  completedAt: string;
  score: number;
  duration: number; // 用时分钟
}

// 单词
export interface Word {
  id: string;
  english: string;
  chinese: string;
  phonetic: string;
  example: string;
  exampleTranslation: string;
  courseId: string;
  lessonId: string;
  image?: string;
}

// 语法练习题
export interface GrammarQuestion {
  id: string;
  lessonId: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

// 听力题
export interface ListeningQuestion {
  id: string;
  lessonId: string;
  audioUrl: string; // 模拟音频标识
  question: string;
  options: string[];
  correctAnswer: number;
  transcript: string;
}

// 成就徽章
export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlockedAt?: string;
  condition: string;
}

// 社区帖子
export interface Post {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  title: string;
  content: string;
  createdAt: string;
  likes: number;
  comments: Comment[];
  tags: string[];
}

export interface Comment {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  content: string;
  createdAt: string;
}

// 每日学习目标
export interface DailyGoal {
  targetMinutes: number;
  completedMinutes: number;
  targetWords: number;
  completedWords: number;
  targetStreak: number;
}

// 推荐学习路径
export interface LearningPath {
  id: string;
  title: string;
  description: string;
  targetLevel: CourseLevel;
  estimatedWeeks: number;
  courses: string[]; // course ids
}

// ========== 口语对话训练 ==========

// 对话角色
export type Role = 'assistant' | 'user';

// 难度
export type Difficulty = 'easy' | 'medium' | 'hard';

// 单轮对话
export interface DialogueLine {
  id: string;
  role: Role;
  english: string;          // 英文台词
  chinese: string;          // 中文翻译
  audioHint?: string;       // 音频提示（关键字）
  keyword?: string[];       // 用户回答需要包含的关键词（用于评分）
  isUser: boolean;          // 是否轮到用户说话
  isPrompt: boolean;        // 是否是给用户的提示（而非必须逐字跟读的台词）
  alternatives?: string[];  // 用户可接受的其他表达方式
}

// 口语对话场景
export interface ConversationScene {
  id: string;
  title: string;
  subtitle: string;         // 副标题/场景描述
  icon: string;             // emoji 图标
  emojiBg: string;          // 背景色类名
  difficulty: Difficulty;
  gradeRange: string;       // 适用年级
  duration: number;         // 预计分钟数
  turns: number;            // 对话轮数
  tags: string[];           // 标签，如 "问候"、"购物"、"点餐"
  characters: {
    assistant: string;      // AI 角色名字
    user: string;           // 用户角色名字
    assistantEmoji: string;
    userEmoji: string;
  };
  opening: string;          // 场景开场/背景
  dialogues: DialogueLine[];
  vocabulary: { english: string; chinese: string }[]; // 本场景核心词汇
  tips: string[];           // 学习小贴士
}

// 对话气泡（UI层使用）
export interface ChatBubble {
  id: string;
  role: Role;
  english: string;
  chinese?: string;
  timestamp: number;
  isSystem?: boolean;
  score?: number;
  feedback?: string;
  isUserAttempt?: boolean;  // 用户尝试（语音或文字）
  isReference?: boolean;    // 参考示范
}
