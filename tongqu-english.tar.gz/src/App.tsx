import { RouterProvider } from 'react-router-dom';
import router from '@/router';
import { useAuthStore } from '@/stores/authStore';
import { useCommunityStore } from '@/stores/communityStore';
import { useEffect } from 'react';

function App() {
  const { isAuthenticated } = useAuthStore();
  const { initPosts } = useCommunityStore();
  
  useEffect(() => {
    initPosts();
  }, [initPosts]);

  return <RouterProvider router={router} />;
}

export default App;
