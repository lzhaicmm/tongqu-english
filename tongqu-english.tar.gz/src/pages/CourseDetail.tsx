import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Star, Users, Clock, BookOpen, Play, Lock, CheckCircle, ChevronRight, Award } from 'lucide-react';
import { mockCourses, mockLearningPaths } from '@/data/mockData';
import { levelNames } from '@/utils';
import { useLearningStore } from '@/stores/learningStore';
import { useAuthStore } from '@/stores/authStore';

export default function CourseDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuthStore();
  const { isLessonCompleted, getCourseProgress } = useLearningStore();

  const course = mockCourses.find(c => c.id === id);

  if (!course) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold mb-4">课程不存在</h1>
        <Link to="/courses" className="text-kids-blue hover:underline">返回课程列表</Link>
      </div>
    );
  }

  const progress = getCourseProgress(course.id, course.lessons.length);
  const typeIcons: Record<string, string> = {
    vocabulary: '📖',
    grammar: '📝',
    speaking: '🎤',
    listening: '🎧',
  };
  const typeLabels: Record<string, string> = {
    vocabulary: '单词记忆',
    grammar: '语法练习',
    speaking: '口语跟读',
    listening: '听力训练',
  };

  const getLessonLink = (lessonId: string, type: string, isFree: boolean) => {
    if (!isAuthenticated) return '/login';
    if (!isFree) return '#';
    const typePath: Record<string, string> = {
      vocabulary: 'word',
      grammar: 'grammar',
      speaking: 'speaking',
      listening: 'listening',
    };
    return `/learn/${typePath[type]}/${lessonId}`;
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back */}
      <Link to="/courses" className="inline-flex items-center gap-2 text-gray-500 hover:text-kids-blue mb-6 transition-colors">
        <ArrowLeft size={18} /> 返回课程列表
      </Link>

      {/* Course Header */}
      <div className={`bg-gradient-to-br from-${course.color} to-${course.color === 'kids-blue' ? 'kids-purple' : 'kids-pink'} rounded-3xl p-8 text-white mb-8 relative overflow-hidden shadow-xl`}>
        {/* Decorative */}
        <div className="absolute inset-0 opacity-20">
          {['⭐', '🌟', '✨', '🎈'].map((e, i) => (
            <span key={i} className="absolute text-4xl" style={{ top: `${10 + i * 20}%`, left: `${60 + i * 10}%` }}>
              {e}
            </span>
          ))}
        </div>

        <div className="relative flex flex-col md:flex-row items-start gap-6">
          <div className="w-28 h-28 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center text-6xl flex-shrink-0">
            {course.icon}
          </div>
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className="px-3 py-1 bg-white/20 rounded-full text-sm font-medium">{levelNames[course.level]}</span>
              <span className="px-3 py-1 bg-white/20 rounded-full text-sm">{course.gradeRange}</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-3">{course.title}</h1>
            <p className="text-white/90 text-lg mb-4 max-w-2xl">{course.description}</p>
            <div className="flex flex-wrap items-center gap-5 text-sm">
              <div className="flex items-center gap-1.5">
                <Star size={16} className="fill-yellow-400 text-yellow-400" />
                <span>{course.rating} 分</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Users size={16} />
                <span>{course.studentsCount.toLocaleString()} 人已学</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock size={16} />
                <span>约 {course.estimatedHours} 小时</span>
              </div>
              <div className="flex items-center gap-1.5">
                <BookOpen size={16} />
                <span>{course.totalLessons} 课时</span>
              </div>
            </div>
          </div>
        </div>

        {/* Progress */}
        {progress > 0 && (
          <div className="relative mt-6 bg-white/20 backdrop-blur-sm rounded-xl p-4">
            <div className="flex items-center justify-between text-sm mb-2">
              <span>学习进度</span>
              <span className="font-bold">{progress}%</span>
            </div>
            <div className="h-2 bg-white/30 rounded-full overflow-hidden">
              <div 
                className="h-full bg-white rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Course Content */}
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Lessons List */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <div className="p-5 border-b flex items-center gap-2">
              <span className="text-xl">📋</span>
              <h2 className="font-bold text-gray-800">课程目录</h2>
              <span className="text-sm text-gray-400">({course.lessons.length} 课时)</span>
            </div>
            <div className="divide-y">
              {course.lessons.map((lesson, index) => {
                const completed = isLessonCompleted(lesson.id);
                const lessonLink = getLessonLink(lesson.id, lesson.type, lesson.isFree);

                return (
                  <div
                    key={lesson.id}
                    className="p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      {/* Number/Badge */}
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm flex-shrink-0 ${
                        completed ? 'bg-green-100 text-green-600' :
                        lesson.isFree ? 'bg-blue-100 text-blue-600' :
                        'bg-gray-100 text-gray-400'
                      }`}>
                        {completed ? <CheckCircle size={20} /> : index + 1}
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-lg">{typeIcons[lesson.type]}</span>
                          <h3 className="font-semibold text-gray-800">{lesson.title}</h3>
                          {lesson.isFree && (
                            <span className="text-xs px-2 py-0.5 bg-green-100 text-green-600 rounded-full font-medium">
                              免费
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-3 text-xs text-gray-400">
                          <span>{typeLabels[lesson.type]}</span>
                          <span className="flex items-center gap-1">
                            <Clock size={12} /> {lesson.duration}分钟
                          </span>
                        </div>
                      </div>

                      {/* Action */}
                      {lessonLink === '#' ? (
                        <div className="flex items-center gap-1 text-gray-400 text-sm">
                          <Lock size={14} /> 解锁
                        </div>
                      ) : (
                        <Link
                          to={lessonLink}
                          className={`flex items-center gap-1 px-4 py-2 rounded-xl font-medium text-sm transition-all ${
                            completed 
                              ? 'bg-green-50 text-green-600 hover:bg-green-100'
                              : 'bg-gradient-to-r from-kids-blue to-kids-purple text-white hover:shadow-lg hover:scale-105'
                          }`}
                        >
                          <Play size={14} fill="currentColor" />
                          {completed ? '再学一次' : '开始学习'}
                        </Link>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Quick Start */}
          <div className="bg-white rounded-2xl shadow-sm p-5">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <span className="text-xl">⚡</span> 快速开始
            </h3>
            {!isAuthenticated ? (
              <Link
                to="/login"
                className="block w-full py-3 text-center bg-gradient-to-r from-kids-blue to-kids-purple text-white font-semibold rounded-xl hover:shadow-lg transition-all"
              >
                登录开启学习
              </Link>
            ) : (
              <Link
                to={(() => {
                  const nextLesson = course.lessons.find(l => !isLessonCompleted(l.id) && l.isFree) || course.lessons.find(l => l.isFree);
                  if (!nextLesson) return '#';
                  const typePath: Record<string, string> = {
                    vocabulary: 'word', grammar: 'grammar', speaking: 'speaking', listening: 'listening'
                  };
                  return `/learn/${typePath[nextLesson.type]}/${nextLesson.id}`;
                })()}
                className="block w-full py-3 text-center bg-gradient-to-r from-green-400 to-emerald-500 text-white font-semibold rounded-xl hover:shadow-lg transition-all"
              >
                <Play size={18} className="inline mr-1" fill="currentColor" />
                {progress > 0 ? '继续学习' : '开始学习'}
              </Link>
            )}
          </div>

          {/* What You'll Learn */}
          <div className="bg-white rounded-2xl shadow-sm p-5">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <span className="text-xl">🎯</span> 你将学到
            </h3>
            <ul className="space-y-3 text-sm text-gray-600">
              <li className="flex items-start gap-2">
                <CheckCircle size={16} className="text-green-500 flex-shrink-0 mt-0.5" />
                <span>核心词汇 {course.totalLessons * 6}+ 个</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle size={16} className="text-green-500 flex-shrink-0 mt-0.5" />
                <span>重点语法 {Math.floor(course.totalLessons / 3)}+ 个</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle size={16} className="text-green-500 flex-shrink-0 mt-0.5" />
                <span>听力与口语专项训练</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle size={16} className="text-green-500 flex-shrink-0 mt-0.5" />
                <span>游戏化互动练习巩固</span>
              </li>
            </ul>
          </div>

          {/* Certificate */}
          <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-2xl p-5 border border-yellow-100">
            <div className="flex items-center gap-3 mb-3">
              <Award className="text-yellow-600" size={28} />
              <div>
                <h3 className="font-bold text-gray-800">完成课程证书</h3>
                <p className="text-xs text-gray-500">学完所有课时即可获得</p>
              </div>
            </div>
            <div className="text-center py-3 bg-white/50 rounded-xl">
              <div className="text-4xl mb-1">🏅</div>
              <div className="text-sm font-medium text-yellow-700">{course.title}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
