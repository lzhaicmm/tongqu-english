import { Link } from 'react-router-dom';
import { BarChart3, Target, Flame, Clock, Star, Trophy, BookOpen, TrendingUp, Award, ChevronRight, Sparkles, Zap } from 'lucide-react';
import { mockCourses, mockBadges, mockLearningPaths } from '@/data/mockData';
import { useAuthStore } from '@/stores/authStore';
import { useLearningStore } from '@/stores/learningStore';
import { expToNextLevel, levelNames } from '@/utils';

export default function Dashboard() {
  const { user, isAuthenticated } = useAuthStore();
  const { getCourseProgress, getWeeklyData, getMasteredWords, getTodayStudyMinutes } = useLearningStore();

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 py-12 px-4">
        <div className="text-center max-w-md">
          <div className="text-8xl mb-6">🔐</div>
          <h1 className="text-3xl font-bold text-gray-800 mb-3">欢迎回来！</h1>
          <p className="text-gray-500 mb-8">登录后查看你的学习数据和个性化推荐</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/login"
              className="px-8 py-3 bg-gradient-to-r from-kids-blue to-kids-purple text-white font-semibold rounded-xl hover:shadow-lg transition-all"
            >
              立即登录
            </Link>
            <Link
              to="/register"
              className="px-8 py-3 bg-white text-kids-blue font-semibold rounded-xl border-2 border-kids-blue hover:shadow-lg transition-all"
            >
              免费注册
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const levelInfo = expToNextLevel(user.exp);
  const weeklyData = getWeeklyData();
  const masteredWords = getMasteredWords();
  const todayMinutes = getTodayStudyMinutes();

  // Recent courses with progress
  const coursesWithProgress = mockCourses.map(c => ({
    ...c,
    progress: getCourseProgress(c.id, c.lessons.length),
  }));

  // Unlocked badges (simulated)
  const unlockedBadges = mockBadges.slice(0, Math.min(3 + Math.floor(user.level / 2), mockBadges.length));
  const lockedBadges = mockBadges.slice(unlockedBadges.length);

  // Weekly max for chart scaling
  const maxMinutes = Math.max(...weeklyData.map(d => d.minutes), 60);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-kids-blue via-kids-purple to-kids-pink rounded-3xl p-8 text-white mb-8 relative overflow-hidden shadow-xl">
        {/* Decorative */}
        <div className="absolute inset-0 opacity-20">
          {['🌟', '⭐', '✨', '🎈'].map((e, i) => (
            <span key={i} className="absolute text-5xl" style={{ top: `${10 + i * 25}%`, right: `${5 + i * 15}%` }}>
              {e}
            </span>
          ))}
        </div>
        
        <div className="relative flex flex-col md:flex-row items-start gap-6">
          <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center text-5xl flex-shrink-0">
            {user.avatar}
          </div>
          <div className="flex-1">
            <h1 className="text-3xl font-bold mb-1">你好，{user.username}！</h1>
            <p className="text-white/80 mb-4">今天也要加油学英语哦 💪</p>
            
            {/* Level Progress */}
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="flex items-center gap-1">
                  <Star size={16} className="fill-yellow-400 text-yellow-400" />
                  <span className="font-bold">Level {user.level}</span>
                </span>
                <span>{levelInfo.current} / {levelInfo.next} EXP</span>
              </div>
              <div className="h-3 bg-white/30 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-yellow-400 rounded-full transition-all duration-500"
                  style={{ width: `${levelInfo.progress}%` }}
                />
              </div>
            </div>
          </div>
          
          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 w-full md:w-auto">
            <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
              <Flame size={20} className="mx-auto mb-1 text-orange-300" />
              <div className="text-xl font-bold">{user.streakDays}</div>
              <div className="text-xs text-white/70">连续天数</div>
            </div>
            <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
              <Zap size={20} className="mx-auto mb-1 text-yellow-300" />
              <div className="text-xl font-bold">{user.coins}</div>
              <div className="text-xs text-white/70">金币</div>
            </div>
            <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
              <BookOpen size={20} className="mx-auto mb-1 text-blue-200" />
              <div className="text-xl font-bold">{masteredWords}</div>
              <div className="text-xs text-white/70">掌握单词</div>
            </div>
            <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
              <Clock size={20} className="mx-auto mb-1 text-green-200" />
              <div className="text-xl font-bold">{todayMinutes}</div>
              <div className="text-xs text-white/70">今日分钟</div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Start & Goal */}
      <div className="grid lg:grid-cols-3 gap-6 mb-8">
        {/* Daily Goal */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Target className="text-kids-blue" size={20} />
            今日学习目标
          </h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">学习时长</span>
                <span className="font-bold text-kids-blue">{todayMinutes} / 30分钟</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-blue-400 to-blue-500 rounded-full"
                  style={{ width: `${Math.min((todayMinutes / 30) * 100, 100)}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">连续打卡</span>
                <span className="font-bold text-orange-500">{user.streakDays} 天</span>
              </div>
              <div className="flex gap-1">
                {Array.from({ length: 7 }).map((_, i) => (
                  <div 
                    key={i}
                    className={`flex-1 h-3 rounded-full ${
                      i < user.streakDays % 7 ? 'bg-orange-400' : 'bg-gray-100'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Weekly Chart */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-800 flex items-center gap-2">
              <BarChart3 className="text-kids-purple" size={20} />
              本周学习时长
            </h3>
            <TrendingUp size={20} className="text-green-500" />
          </div>
          <div className="flex items-end gap-3 h-40">
            {weeklyData.map((d, i) => (
              <div key={i} className="flex-1 flex flex-col items-center">
                <span className="text-xs text-gray-400 mb-1">{d.minutes}分钟</span>
                <div 
                  className="w-full bg-gradient-to-t from-kids-purple to-kids-pink rounded-t-lg transition-all duration-500"
                  style={{ height: `${(d.minutes / maxMinutes) * 120}px` }}
                />
                <span className="text-xs text-gray-500 mt-2">{d.day}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Course Progress */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-gray-800 flex items-center gap-2">
                <BookOpen className="text-kids-blue" size={20} />
                我的课程
              </h3>
              <Link to="/courses" className="text-sm text-kids-blue hover:underline flex items-center gap-1">
                全部课程 <ChevronRight size={14} />
              </Link>
            </div>
            
            <div className="space-y-4">
              {coursesWithProgress.map(course => (
                <div 
                  key={course.id} 
                  className="flex items-center gap-4 p-4 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <div className={`w-14 h-14 rounded-xl flex items-center justify-center text-3xl bg-gradient-to-br from-${course.color} to-${course.color === 'kids-blue' ? 'kids-purple' : 'kids-pink'} flex-shrink-0`}>
                    {course.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-gray-800 truncate">{course.title}</h4>
                    <div className="flex items-center gap-3 text-xs text-gray-400 mb-2">
                      <span>{levelNames[course.level]}</span>
                      <span>•</span>
                      <span>{course.totalLessons}节课</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-kids-blue to-kids-purple rounded-full"
                          style={{ width: `${course.progress}%` }}
                        />
                      </div>
                      <span className="text-sm font-bold text-kids-blue">{course.progress}%</span>
                    </div>
                  </div>
                  <Link
                    to={`/courses/${course.id}`}
                    className="px-4 py-2 bg-kids-blue/10 text-kids-blue rounded-lg text-sm font-medium hover:bg-kids-blue hover:text-white transition-all flex-shrink-0"
                  >
                    {course.progress > 0 ? '继续' : '开始'}
                  </Link>
                </div>
              ))}
            </div>
          </div>

          {/* Recommended Learning Path */}
          <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-2xl p-6 border border-yellow-100">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Sparkles className="text-yellow-500" size={20} />
              为你推荐的学习路径
            </h3>
            <div className="grid sm:grid-cols-2 gap-4">
              {mockLearningPaths.slice(0, 2).map(path => (
                <div key={path.id} className="bg-white rounded-xl p-4 shadow-sm">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center text-xl">
                      🎯
                    </div>
                    <h4 className="font-semibold text-gray-800">{path.title}</h4>
                  </div>
                  <p className="text-sm text-gray-500 mb-2">{path.description}</p>
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>约 {path.estimatedWeeks} 周完成</span>
                    <Link to="/courses" className="text-orange-500 font-medium hover:underline">查看 →</Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="space-y-6">
          {/* Achievements */}
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-gray-800 flex items-center gap-2">
                <Trophy className="text-yellow-500" size={20} />
                我的成就
              </h3>
              <span className="text-xs text-gray-400">{unlockedBadges.length}/{mockBadges.length}</span>
            </div>
            
            <div className="grid grid-cols-5 gap-2 mb-4">
              {unlockedBadges.slice(0, 5).map(badge => (
                <div key={badge.id} className="aspect-square flex flex-col items-center justify-center bg-gradient-to-br from-yellow-50 to-orange-50 rounded-xl p-1 border border-yellow-100">
                  <span className="text-xl">{badge.icon}</span>
                </div>
              ))}
              {Array.from({ length: Math.max(0, 5 - unlockedBadges.length) }).map((_, i) => (
                <div key={`empty-${i}`} className="aspect-square flex items-center justify-center bg-gray-50 rounded-xl">
                  <span className="text-xl opacity-20">🎖️</span>
                </div>
              ))}
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-medium text-gray-400">即将解锁</h4>
              {lockedBadges.slice(0, 2).map(badge => (
                <div key={badge.id} className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
                  <span className="text-xl opacity-40 grayscale">{badge.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-gray-500">{badge.name}</div>
                    <div className="text-xs text-gray-400">{badge.condition}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Zap className="text-kids-blue" size={20} />
              快速练习
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <Link
                to="/learn/word/lesson-1-1"
                className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl hover:shadow-md transition-all text-center"
              >
                <div className="text-2xl mb-1">📖</div>
                <div className="text-sm font-medium text-gray-700">背单词</div>
              </Link>
              <Link
                to="/learn/grammar/lesson-2-2"
                className="p-4 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl hover:shadow-md transition-all text-center"
              >
                <div className="text-2xl mb-1">✍️</div>
                <div className="text-sm font-medium text-gray-700">练语法</div>
              </Link>
              <Link
                to="/learn/speaking/lesson-1-3"
                className="p-4 bg-gradient-to-br from-pink-50 to-rose-50 rounded-xl hover:shadow-md transition-all text-center"
              >
                <div className="text-2xl mb-1">🎤</div>
                <div className="text-sm font-medium text-gray-700">说口语</div>
              </Link>
              <Link
                to="/learn/listening/lesson-1-5"
                className="p-4 bg-gradient-to-br from-teal-50 to-cyan-50 rounded-xl hover:shadow-md transition-all text-center"
              >
                <div className="text-2xl mb-1">🎧</div>
                <div className="text-sm font-medium text-gray-700">练听力</div>
              </Link>
              <Link
                to="/learn/speaking/lesson-1-3"
                className="p-4 bg-gradient-to-br from-pink-50 to-rose-50 rounded-xl hover:shadow-md transition-all text-center"
              >
                <div className="text-2xl mb-1">🎤</div>
                <div className="text-sm font-medium text-gray-700">口语跟读</div>
              </Link>
              <Link
                to="/conversation"
                className="p-4 bg-gradient-to-br from-pink-100 via-rose-50 to-orange-50 rounded-xl hover:shadow-md transition-all text-center border-2 border-pink-200 relative overflow-hidden"
              >
                <div className="absolute -right-1 -top-1 text-[10px] bg-pink-500 text-white px-2 py-0.5 rounded-bl-lg font-bold">NEW</div>
                <div className="text-2xl mb-1">💬</div>
                <div className="text-sm font-medium text-gray-700">场景对话</div>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
