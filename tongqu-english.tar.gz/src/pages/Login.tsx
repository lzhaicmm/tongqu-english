import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Mail, Lock, Eye, EyeOff, ArrowLeft, AlertCircle } from 'lucide-react';
import { useAuthStore } from '@/stores/authStore';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { login } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    setTimeout(() => {
      const result = login(email, password);
      if (result.success) {
        const from = (location.state as any)?.from?.pathname || '/dashboard';
        navigate(from, { replace: true });
      } else {
        setError(result.message);
      }
      setLoading(false);
    }, 500);
  };

  const fillDemoAccount = () => {
    setEmail('demo@kids.com');
    setPassword('123456');
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gradient-to-br from-kids-blue/10 via-purple-50 to-kids-pink/10 py-12 px-4">
      <div className="w-full max-w-md">
        {/* Card */}
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-br from-kids-blue to-kids-purple p-8 text-center text-white relative overflow-hidden">
            <div className="absolute inset-0 opacity-10">
              {['⭐', '🌟', '✨', '🎈'].map((e, i) => (
                <span
                  key={i}
                  className="absolute text-4xl"
                  style={{ top: `${20 + i * 20}%`, left: `${10 + i * 25}%` }}
                >
                  {e}
                </span>
              ))}
            </div>
            <div className="relative">
              <Link to="/" className="inline-flex items-center gap-2 text-white/80 hover:text-white text-sm mb-6">
                <ArrowLeft size={16} /> 返回首页
              </Link>
              <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full mx-auto flex items-center justify-center text-5xl mb-4">
                🎓
              </div>
              <h1 className="text-2xl font-bold mb-1">欢迎回来！</h1>
              <p className="text-white/80 text-sm">继续你的英语学习之旅</p>
            </div>
          </div>

          {/* Form */}
          <div className="p-8">
            <form onSubmit={handleSubmit} className="space-y-5">
              {error && (
                <div className="flex items-center gap-2 p-3 bg-red-50 text-red-600 rounded-xl text-sm">
                  <AlertCircle size={18} />
                  {error}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">邮箱地址</label>
                <div className="relative">
                  <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="请输入您的邮箱"
                    className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-kids-blue/50 focus:border-kids-blue transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">密码</label>
                <div className="relative">
                  <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="请输入密码"
                    className="w-full pl-10 pr-12 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-kids-blue/50 focus:border-kids-blue transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center gap-2 text-gray-600">
                  <input type="checkbox" className="w-4 h-4 text-kids-blue rounded" />
                  记住我
                </label>
                <a href="#" className="text-kids-blue hover:underline">忘记密码？</a>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-gradient-to-r from-kids-blue to-kids-purple text-white font-semibold rounded-xl hover:shadow-lg hover:scale-[1.02] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? '登录中...' : '登 录'}
              </button>
            </form>

            {/* Demo hint */}
            <button
              onClick={fillDemoAccount}
              className="w-full mt-4 py-2 text-sm text-kids-blue hover:bg-kids-blue/5 rounded-lg transition-colors"
            >
              使用演示账号登录 (demo@kids.com / 123456)
            </button>

            {/* Divider */}
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-400">或使用其他方式</span>
              </div>
            </div>

            {/* Social Login */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { icon: '📱', label: '手机', color: 'bg-green-50 hover:bg-green-100 text-green-600' },
                { icon: '🐦', label: '微信', color: 'bg-blue-50 hover:bg-blue-100 text-blue-600' },
                { icon: '👨', label: 'QQ', color: 'bg-purple-50 hover:bg-purple-100 text-purple-600' },
              ].map((item, i) => (
                <button
                  key={i}
                  className={`py-2.5 rounded-xl font-medium text-sm transition-colors ${item.color}`}
                >
                  <div className="text-xl mb-0.5">{item.icon}</div>
                  {item.label}
                </button>
              ))}
            </div>

            {/* Register Link */}
            <p className="text-center text-sm text-gray-500 mt-6">
              还没有账号？
              <Link to="/register" className="text-kids-blue font-medium hover:underline ml-1">
                立即注册 →
              </Link>
            </p>
          </div>
        </div>

        <p className="text-center text-xs text-gray-400 mt-6">
          登录即表示您同意我们的 <a href="#" className="underline">用户协议</a> 和 <a href="#" className="underline">隐私政策</a>
        </p>
      </div>
    </div>
  );
}
