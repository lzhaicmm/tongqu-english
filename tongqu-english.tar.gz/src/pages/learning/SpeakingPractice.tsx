import { useState, useEffect, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Mic, Square, Volume2, RotateCcw, Play, Sparkles, Star } from 'lucide-react';
import { mockWords } from '@/data/mockData';
import { useLearningStore } from '@/stores/learningStore';
import { useAuthStore } from '@/stores/authStore';
import { speak, calculateSpeakingScore } from '@/utils';

export default function SpeakingPractice() {
  const { lessonId } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated, addExp, addCoins } = useAuthStore();
  const { addRecord } = useLearningStore();

  const words = mockWords[lessonId] || mockWords['lesson-1-3'];
  const sentences = [
    'Hello, how are you?',
    'My name is Tom.',
    'I like apples.',
    'Thank you very much!',
    'See you tomorrow.',
    'Nice to meet you.',
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [hasRecorded, setHasRecorded] = useState(false);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [practiceMode, setPracticeMode] = useState<'word' | 'sentence'>('sentence');
  const [attempts, setAttempts] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [practiceCount, setPracticeCount] = useState(0);

  const recognitionRef = useRef<any>(null);

  const practiceItems = practiceMode === 'word' 
    ? words.slice(0, 6).map(w => w.english)
    : sentences;
  const currentItem = practiceItems[currentIndex];

  useEffect(() => {
    // Check for Speech Recognition API
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.lang = 'en-US';
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      
      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript.toLowerCase().trim();
        const target = currentItem.toLowerCase().trim();
        const similarity = calculateSimilarity(transcript, target);
        const estimatedScore = calculateSpeakingScore(
          similarity,
          0.9,
          similarity > 0.7 ? 1 : 0.7
        );
        
        setScore(estimatedScore);
        setHasRecorded(true);
        setShowResult(true);
        setPracticeCount(c => c + 1);
        
        if (isAuthenticated && user) {
          addExp(Math.floor(estimatedScore / 5));
          addCoins(Math.floor(estimatedScore / 10));
        }

        if (similarity >= 0.9) {
          setFeedback('🎉 太棒了！发音非常标准！');
        } else if (similarity >= 0.75) {
          setFeedback('👍 不错哦！再试试可以更棒！');
        } else if (similarity >= 0.6) {
          setFeedback('💪 继续努力！跟着再读一遍吧！');
        } else {
          setFeedback('📖 先听一遍标准发音，然后再试试！');
        }
      };

      recognitionRef.current.onerror = () => {
        setFeedback('😅 语音识别暂时不可用，请再试一次');
        setIsRecording(false);
      };

      recognitionRef.current.onend = () => {
        setIsRecording(false);
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.onresult = null;
        recognitionRef.current.onerror = null;
        recognitionRef.current.onend = null;
      }
    };
  }, [currentItem]);

  useEffect(() => {
    if (showResult && isAuthenticated && user && currentIndex === practiceItems.length - 1) {
      addRecord({
        userId: user.id,
        lessonId: lessonId!,
        courseId: '',
        score: Math.round(score),
        duration: Math.max(5, practiceCount * 2),
      });
    }
  }, [showResult]);

  const calculateSimilarity = (str1: string, str2: string): number => {
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    if (longer.length === 0) return 1.0;
    
    const costs: number[][] = [];
    for (let i = 0; i <= shorter.length; i++) {
      costs[i] = [i];
    }
    for (let j = 0; j <= longer.length; j++) {
      costs[0][j] = j;
    }
    
    for (let i = 1; i <= shorter.length; i++) {
      for (let j = 1; j <= longer.length; j++) {
        if (shorter.charAt(i - 1) === longer.charAt(j - 1)) {
          costs[i][j] = costs[i - 1][j - 1];
        } else {
          costs[i][j] = Math.min(
            costs[i - 1][j - 1] + 1,
            costs[i][j - 1] + 1,
            costs[i - 1][j] + 1
          );
        }
      }
    }
    
    return (longer.length - costs[shorter.length][longer.length]) / longer.length;
  };

  const startRecording = () => {
    setFeedback('');
    setShowResult(false);
    setAttempts(a => a + 1);
    
    if (recognitionRef.current) {
      setIsRecording(true);
      recognitionRef.current.start();
    } else {
      // Fallback: simulate scoring
      setIsRecording(true);
      setTimeout(() => {
        const simulatedScore = 60 + Math.floor(Math.random() * 35);
        setScore(simulatedScore);
        setHasRecorded(true);
        setShowResult(true);
        
        if (simulatedScore >= 85) {
          setFeedback('🎉 太棒了！发音非常标准！');
        } else if (simulatedScore >= 70) {
          setFeedback('👍 不错哦！再试试可以更棒！');
        } else {
          setFeedback('💪 继续努力！跟着再读一遍吧！');
        }
        setIsRecording(false);
      }, 2000);
    }
  };

  const stopRecording = () => {
    if (recognitionRef.current && isRecording) {
      recognitionRef.current.stop();
    }
  };

  const handleNext = () => {
    if (currentIndex < practiceItems.length - 1) {
      setCurrentIndex(i => i + 1);
      setHasRecorded(false);
      setShowResult(false);
      setScore(0);
      setFeedback('');
    } else {
      navigate('/dashboard');
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setHasRecorded(false);
    setShowResult(false);
    setScore(0);
    setFeedback('');
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🔒</div>
          <h2 className="text-xl font-bold mb-2">请先登录</h2>
          <Link to="/login" className="text-kids-blue hover:underline">去登录 →</Link>
        </div>
      </div>
    );
  }

  const progress = ((currentIndex + 1) / practiceItems.length) * 100;

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-pink-50 via-rose-50 to-red-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-gray-500 hover:text-pink-500">
            <ArrowLeft size={20} /> 返回
          </button>
          <span className="text-sm text-gray-500">🎤 口语跟读</span>
        </div>

        {/* Mode Switch */}
        <div className="bg-white rounded-2xl p-2 mb-6 shadow-sm flex gap-2">
          <button
            onClick={() => { setPracticeMode('word'); handleRestart(); }}
            className={`flex-1 py-2 rounded-xl font-medium transition-all ${
              practiceMode === 'word' ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white shadow-md' : 'text-gray-500'
            }`}
          >
            单词模式
          </button>
          <button
            onClick={() => { setPracticeMode('sentence'); handleRestart(); }}
            className={`flex-1 py-2 rounded-xl font-medium transition-all ${
              practiceMode === 'sentence' ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white shadow-md' : 'text-gray-500'
            }`}
          >
            句子模式
          </button>
        </div>

        {/* Progress */}
        <div className="mb-6">
          <div className="flex justify-between text-sm text-gray-500 mb-2">
            <span>🎯 跟着标准发音读一遍</span>
            <span>{currentIndex + 1} / {practiceItems.length}</span>
          </div>
          <div className="h-3 bg-white rounded-full overflow-hidden shadow-inner">
            <div 
              className="h-full bg-gradient-to-r from-pink-500 to-rose-500 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Practice Area */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-6">
          {/* Target Text */}
          <div className="text-center mb-8">
            <p className="text-sm text-gray-400 mb-3">请跟读下面的内容</p>
            <div className="text-3xl md:text-4xl font-bold text-gray-800 mb-4 leading-relaxed">
              {currentItem}
            </div>
            <button 
              onClick={() => speak(currentItem)}
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-pink-100 to-rose-100 text-pink-600 rounded-full hover:shadow-md hover:scale-105 transition-all font-medium"
            >
              <Play size={18} fill="currentColor" /> 听标准发音
            </button>
          </div>

          {/* Recording Button */}
          <div className="flex flex-col items-center py-8">
            <button
              onClick={isRecording ? stopRecording : startRecording}
              disabled={showResult && score >= 70}
              className={`w-32 h-32 rounded-full flex items-center justify-center transition-all shadow-xl ${
                isRecording 
                  ? 'bg-gradient-to-br from-red-500 to-rose-600 animate-pulse scale-110' 
                  : 'bg-gradient-to-br from-pink-400 to-rose-500 hover:scale-110'
              } ${showResult && score >= 70 ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {isRecording ? (
                <Square size={48} className="text-white" fill="white" />
              ) : (
                <Mic size={48} className="text-white" />
              )}
            </button>
            <p className="mt-4 text-sm text-gray-500">
              {isRecording ? '正在录音... 点击停止' : hasRecorded ? '再来一次？' : '点击麦克风开始录音'}
            </p>
            {attempts > 0 && (
              <p className="text-xs text-gray-400 mt-2">已尝试 {attempts} 次</p>
            )}
          </div>

          {/* Feedback */}
          {showResult && (
            <div className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-2xl p-6 border border-pink-100">
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 relative flex items-center justify-center">
                  <svg className="w-20 h-20" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="40" fill="none" stroke="#FCE7F3" strokeWidth="8" />
                    <circle 
                      cx="50" cy="50" r="40" fill="none" 
                      stroke={score >= 85 ? '#22C55E' : score >= 70 ? '#F59E0B' : '#EF4444'} 
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={`${(score / 100) * 251} 251`}
                      transform="rotate(-90 50 50)"
                    />
                  </svg>
                  <span className="absolute text-xl font-bold text-gray-700">{score}</span>
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 mb-1">发音评分</h4>
                  <p className="text-gray-600 text-sm">{feedback}</p>
                  <div className="flex items-center gap-1 mt-2">
                    {[1, 2, 3, 4, 5].map(i => (
                      <Star 
                        key={i} 
                        size={16} 
                        className={i <= Math.ceil(score / 20) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'} 
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex gap-3">
          <button
            onClick={handleRestart}
            className="px-6 py-3 bg-white rounded-xl shadow-md font-medium hover:shadow-lg transition-all flex items-center gap-2"
          >
            <RotateCcw size={18} /> 重新开始
          </button>
          {showResult && (
            <button
              onClick={handleNext}
              className="flex-1 py-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white font-bold rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
            >
              {currentIndex < practiceItems.length - 1 ? '下一个 →' : <><Sparkles size={18} />完成</>}
            </button>
          )}
        </div>

        {/* Browser Support Note */}
        {!recognitionRef.current && (
          <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-700 text-center">
            💡 提示：您的浏览器暂不支持实时语音识别，我们将为您模拟评分效果。推荐使用 Chrome 浏览器获得最佳体验！
          </div>
        )}
      </div>
    </div>
  );
}
