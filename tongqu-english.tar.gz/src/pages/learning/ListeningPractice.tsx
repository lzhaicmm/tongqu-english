import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Headphones, Play, Volume2, Sparkles, Check, X } from 'lucide-react';
import { mockListeningQuestions } from '@/data/mockData';
import { useLearningStore } from '@/stores/learningStore';
import { useAuthStore } from '@/stores/authStore';
import { speak } from '@/utils';
import { shuffle } from '@/utils';

export default function ListeningPractice() {
  const { lessonId } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated, addExp, addCoins } = useAuthStore();
  const { addRecord } = useLearningStore();

  const questions = mockListeningQuestions[lessonId] || mockListeningQuestions['lesson-1-5'];
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [hasPlayed, setHasPlayed] = useState(false);
  const [showResult, setShowResult] = useState(false);

  useEffect(() => {
    if (showResult && isAuthenticated && user) {
      const exp = score * 12;
      const coins = score * 6;
      addExp(exp);
      addCoins(coins);
      addRecord({
        userId: user.id,
        lessonId: lessonId!,
        courseId: '',
        score: Math.round((score / questions.length) * 100),
        duration: questions.length * 3,
      });
    }
  }, [showResult]);

  const handlePlayAudio = () => {
    const q = questions[currentIndex];
    speak(q.transcript, 'en-US');
    setHasPlayed(true);
  };

  const handleSelect = (index: number) => {
    if (selectedAnswer !== null || !hasPlayed) return;
    setSelectedAnswer(index);
    if (index === questions[currentIndex].correctAnswer) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(i => i + 1);
      setSelectedAnswer(null);
      setHasPlayed(false);
    } else {
      setShowResult(true);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🔒</div>
          <h2 className="text-xl font-bold mb-2">请先登录</h2>
          <Link to="/login" className="text-kids-blue hover:underline">去登录 →</Link>
        </div>
      </div>
    );
  }

  if (showResult) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50 py-8 px-4 flex items-center">
        <div className="max-w-md mx-auto w-full">
          <div className="bg-white rounded-3xl shadow-2xl p-8 text-center">
            <div className="text-7xl mb-4">
              {percentage === 100 ? '🎧👑' : percentage >= 80 ? '🎧🏆' : percentage >= 60 ? '🎧👍' : '🎧📚'}
            </div>
            <h2 className="text-3xl font-bold text-gray-800 mb-2">
              {percentage === 100 ? '听力大师！' : percentage >= 80 ? '听力高手！' : percentage >= 60 ? '继续加油！' : '多听多练！'}
            </h2>
            <p className="text-gray-500 mb-6">答对 {score} / {questions.length} 题</p>

            <div className="relative w-40 h-40 mx-auto mb-6">
              <svg className="w-full h-full" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="45" fill="none" stroke="#E5E7EB" strokeWidth="8" />
                <circle 
                  cx="50" cy="50" r="45" fill="none" 
                  stroke="url(#listen-gradient)" 
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${(score / questions.length) * 283} 283`}
                  transform="rotate(-90 50 50)"
                />
                <defs>
                  <linearGradient id="listen-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#06B6D4" />
                    <stop offset="100%" stopColor="#3B82F6" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-bold">{percentage}%</span>
                <span className="text-xs text-gray-400">正确率</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="p-4 bg-cyan-50 rounded-2xl">
                <div className="text-2xl mb-1">⭐</div>
                <div className="text-2xl font-bold text-cyan-600">+{score * 12}</div>
                <div className="text-xs text-gray-500">经验值</div>
              </div>
              <div className="p-4 bg-yellow-50 rounded-2xl">
                <div className="text-2xl mb-1">🪙</div>
                <div className="text-2xl font-bold text-yellow-600">+{score * 6}</div>
                <div className="text-xs text-gray-500">金币</div>
              </div>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setCurrentIndex(0);
                  setScore(0);
                  setShowResult(false);
                  setSelectedAnswer(null);
                  setHasPlayed(false);
                }}
                className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-semibold rounded-xl hover:shadow-lg transition-all"
              >
                再练一次
              </button>
              <Link
                to="/dashboard"
                className="w-full py-3 bg-gray-100 text-gray-700 font-semibold rounded-xl hover:bg-gray-200 transition-all block text-center"
              >
                返回学习中心
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentIndex];
  const progress = ((currentIndex + 1) / questions.length) * 100;
  const isCorrect = selectedAnswer === currentQ.correctAnswer;

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-gray-500 hover:text-cyan-500">
            <ArrowLeft size={20} /> 返回
          </button>
          <span className="text-sm text-gray-500">🎧 听力训练</span>
        </div>

        {/* Progress */}
        <div className="mb-6">
          <div className="flex justify-between text-sm text-gray-500 mb-2">
            <span>🎯 先听音频，再回答问题</span>
            <span>{currentIndex + 1} / {questions.length}</span>
          </div>
          <div className="h-3 bg-white rounded-full overflow-hidden shadow-inner">
            <div 
              className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Listening Card */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-6">
          {/* Audio Player */}
          <div className="text-center py-8 mb-8">
            <div className={`w-40 h-40 mx-auto mb-6 rounded-full flex items-center justify-center transition-all ${
              hasPlayed 
                ? 'bg-gradient-to-br from-cyan-400 to-blue-500 animate-pulse' 
                : 'bg-gradient-to-br from-cyan-100 to-blue-100'
            }`}>
              <Headphones size={64} className={hasPlayed ? 'text-white' : 'text-cyan-400'} />
            </div>
            <button
              onClick={handlePlayAudio}
              className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-bold rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all"
            >
              <Volume2 size={22} /> {hasPlayed ? '再听一遍' : '播放音频'}
            </button>
            {!hasPlayed && (
              <p className="text-sm text-gray-400 mt-3">⚠️ 请先听音频再选择答案</p>
            )}
          </div>

          {/* Question */}
          <div className={`${!hasPlayed ? 'opacity-50 pointer-events-none' : ''}`}>
            <div className="text-sm text-cyan-600 font-medium mb-2">听力理解</div>
            <h2 className="text-xl font-bold text-gray-800 mb-6">{currentQ.question}</h2>

            {/* Options */}
            <div className="space-y-3">
              {shuffle(currentQ.options).map((option, i) => {
                let style = 'bg-gray-50 hover:bg-cyan-50 border-gray-200 hover:border-cyan-300';
                if (selectedAnswer !== null) {
                  if (i === currentQ.correctAnswer) {
                    style = 'bg-green-50 border-green-500';
                  } else if (i === selectedAnswer) {
                    style = 'bg-red-50 border-red-500';
                  } else {
                    style = 'bg-gray-50 border-gray-200 opacity-50';
                  }
                }
                return (
                  <button
                    key={i}
                    onClick={() => handleSelect(i)}
                    disabled={selectedAnswer !== null}
                    className={`w-full p-4 rounded-2xl border-2 font-medium text-lg transition-all text-left flex items-center gap-3 ${style}`}
                  >
                    <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                      selectedAnswer !== null && i === currentQ.correctAnswer ? 'bg-green-500 text-white' :
                      selectedAnswer === i && i !== currentQ.correctAnswer ? 'bg-red-500 text-white' :
                      'bg-gray-200 text-gray-500'
                    }`}>
                      {String.fromCharCode(65 + i)}
                    </span>
                    <span className="flex-1">{option}</span>
                    {selectedAnswer !== null && i === currentQ.correctAnswer && <Check className="text-green-500" size={20} />}
                    {selectedAnswer === i && i !== currentQ.correctAnswer && <X className="text-red-500" size={20} />}
                  </button>
                );
              })}
            </div>

            {/* Show transcript hint */}
            {selectedAnswer !== null && !isCorrect && (
              <div className="mt-4 p-4 bg-blue-50 rounded-xl text-sm text-blue-700">
                <strong>🎯 听力原文：</strong> "{currentQ.transcript}"
              </div>
            )}
          </div>

          {/* Next Button */}
          {selectedAnswer !== null && (
            <button
              onClick={handleNext}
              className="mt-6 w-full py-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-bold text-lg rounded-2xl hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              {currentIndex < questions.length - 1 ? '下一题 →' : <><Sparkles size={18} />查看结果</>}
            </button>
          )}
        </div>

        {/* Tip */}
        <div className="bg-gradient-to-r from-amber-50 to-yellow-50 rounded-2xl p-5 border border-amber-100">
          <h4 className="font-bold text-amber-700 mb-2 flex items-center gap-2">
            <Play size={16} fill="currentColor" /> 听力小技巧
          </h4>
          <ul className="text-sm text-amber-600 space-y-1">
            <li>• 先仔细听一遍，注意语音语调</li>
            <li>• 听完别急着选答案，先理清大意</li>
            <li>• 不确定可以点击"再听一遍"</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
