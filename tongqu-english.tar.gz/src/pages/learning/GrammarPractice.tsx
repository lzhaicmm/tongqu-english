import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Check, X, Lightbulb, RotateCcw, Sparkles } from 'lucide-react';
import { mockGrammarQuestions } from '@/data/mockData';
import { useLearningStore } from '@/stores/learningStore';
import { useAuthStore } from '@/stores/authStore';
import { shuffle } from '@/utils';

type Mode = 'practice' | 'result';

export default function GrammarPractice() {
  const { lessonId } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated, addExp, addCoins } = useAuthStore();
  const { addRecord } = useLearningStore();

  const allQuestions = mockGrammarQuestions[lessonId] || mockGrammarQuestions['lesson-2-2'];
  const questions = shuffle(allQuestions).slice(0, Math.min(allQuestions.length, 5));
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [mode, setMode] = useState<Mode>('practice');

  useEffect(() => {
    if (mode === 'result' && isAuthenticated && user) {
      const exp = score * 15;
      const coins = score * 8;
      addExp(exp);
      addCoins(coins);
      addRecord({
        userId: user.id,
        lessonId: lessonId!,
        courseId: '',
        score: Math.round((score / questions.length) * 100),
        duration: 10,
      });
    }
  }, [mode]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🔒</div>
          <h2 className="text-xl font-bold mb-2">请先登录</h2>
          <Link to="/login" className="text-kids-blue hover:underline">去登录 →</Link>
        </div>
      </div>
    );
  }

  if (mode === 'result') {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 py-8 px-4 flex items-center">
        <div className="max-w-md mx-auto w-full">
          <div className="bg-white rounded-3xl shadow-2xl p-8 text-center">
            <div className="text-7xl mb-4">
              {percentage >= 80 ? '🏆' : percentage >= 60 ? '👍' : '📚'}
            </div>
            <h2 className="text-3xl font-bold text-gray-800 mb-2">
              {percentage >= 80 ? '语法小能手！' : percentage >= 60 ? '还不错哦！' : '继续练习！'}
            </h2>
            <p className="text-gray-500 mb-6">答对 {score} / {questions.length} 题</p>

            {/* Score Circle */}
            <div className="relative w-40 h-40 mx-auto mb-6">
              <svg className="w-full h-full" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="45" fill="none" stroke="#E5E7EB" strokeWidth="8" />
                <circle 
                  cx="50" cy="50" r="45" fill="none" 
                  stroke="url(#g-gradient)" 
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${(score / questions.length) * 283} 283`}
                  transform="rotate(-90 50 50)"
                />
                <defs>
                  <linearGradient id="g-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#6366F1" />
                    <stop offset="100%" stopColor="#8B5CF6" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-bold">{percentage}%</span>
                <span className="text-xs text-gray-400">正确率</span>
              </div>
            </div>

            {/* Rewards */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="p-4 bg-indigo-50 rounded-2xl">
                <div className="text-2xl mb-1">⭐</div>
                <div className="text-2xl font-bold text-indigo-600">+{score * 15}</div>
                <div className="text-xs text-gray-500">经验值</div>
              </div>
              <div className="p-4 bg-yellow-50 rounded-2xl">
                <div className="text-2xl mb-1">🪙</div>
                <div className="text-2xl font-bold text-yellow-600">+{score * 8}</div>
                <div className="text-xs text-gray-500">金币</div>
              </div>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => { setCurrentIndex(0); setMode('practice'); setScore(0); }}
                className="w-full py-3 bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-semibold rounded-xl hover:shadow-lg transition-all flex items-center justify-center gap-2"
              >
                <RotateCcw size={18} /> 再练一次
              </button>
              <Link
                to="/dashboard"
                className="w-full py-3 bg-gray-100 text-gray-700 font-semibold rounded-xl hover:bg-gray-200 transition-all block text-center"
              >
                返回学习中心
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentIndex];
  const progress = ((currentIndex + 1) / questions.length) * 100;
  const isCorrect = selectedAnswer === currentQ.correctAnswer;

  const handleSelect = (index: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(index);
    if (index === currentQ.correctAnswer) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(i => i + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      setMode('result');
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-indigo-50 via-blue-50 to-cyan-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-gray-500 hover:text-indigo-500">
            <ArrowLeft size={20} /> 返回
          </button>
          <span className="text-sm text-gray-500">语法练习</span>
        </div>

        {/* Progress */}
        <div className="mb-6">
          <div className="flex justify-between text-sm text-gray-500 mb-2">
            <span>🎯 聚焦语法知识</span>
            <span>{currentIndex + 1} / {questions.length}</span>
          </div>
          <div className="h-3 bg-white rounded-full overflow-hidden shadow-inner">
            <div 
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-6">
          <div className="text-sm text-indigo-500 font-medium mb-3">选择题</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-8 leading-relaxed">
            {currentQ.question.split('___').map((part, i, arr) => (
              <span key={i}>
                {part}
                {i < arr.length - 1 && (
                  <span className="inline-block mx-2 px-4 py-0.5 bg-indigo-100 text-indigo-600 rounded-lg border-b-2 border-dashed border-indigo-400 min-w-[60px] text-center">
                    ?
                  </span>
                )}
              </span>
            ))}
          </h2>

          {/* Options */}
          <div className="space-y-3">
            {currentQ.options.map((option, i) => {
              let style = 'bg-gray-50 hover:bg-indigo-50 border-gray-200 hover:border-indigo-300 text-gray-700';
              if (selectedAnswer !== null) {
                if (i === currentQ.correctAnswer) {
                  style = 'bg-green-50 border-green-500 text-green-700';
                } else if (i === selectedAnswer) {
                  style = 'bg-red-50 border-red-500 text-red-700';
                } else {
                  style = 'bg-gray-50 border-gray-200 text-gray-400';
                }
              }
              return (
                <button
                  key={i}
                  onClick={() => handleSelect(i)}
                  disabled={selectedAnswer !== null}
                  className={`w-full p-4 rounded-2xl border-2 font-medium text-lg transition-all text-left flex items-center gap-4 ${style}`}
                >
                  <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                    selectedAnswer !== null && i === currentQ.correctAnswer ? 'bg-green-500 text-white' :
                    selectedAnswer === i && i !== currentQ.correctAnswer ? 'bg-red-500 text-white' :
                    'bg-gray-200 text-gray-500'
                  }`}>
                    {String.fromCharCode(65 + i)}
                  </span>
                  <span className="flex-1">{option}</span>
                  {selectedAnswer !== null && i === currentQ.correctAnswer && <Check className="text-green-500" size={22} />}
                  {selectedAnswer === i && i !== currentQ.correctAnswer && <X className="text-red-500" size={22} />}
                </button>
              );
            })}
          </div>

          {/* Next Button */}
          {selectedAnswer !== null && (
            <button
              onClick={handleNext}
              className="mt-6 w-full py-4 bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-bold text-lg rounded-2xl hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              {currentIndex < questions.length - 1 ? '下一题 →' : <><Sparkles size={18} />查看结果</>}
            </button>
          )}
        </div>

        {/* Explanation */}
        {selectedAnswer !== null && (
          <div className={`rounded-2xl p-6 ${isCorrect ? 'bg-green-50 border border-green-200' : 'bg-amber-50 border border-amber-200'}`}>
            <div className="flex items-start gap-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${isCorrect ? 'bg-green-500' : 'bg-amber-500'}`}>
                {isCorrect ? <Check size={20} className="text-white" /> : <Lightbulb size={20} className="text-white" />}
              </div>
              <div>
                <h4 className={`font-bold mb-1 ${isCorrect ? 'text-green-700' : 'text-amber-700'}`}>
                  {isCorrect ? '回答正确！' : '答案解析'}
                </h4>
                <p className="text-gray-600 text-sm leading-relaxed">{currentQ.explanation}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
