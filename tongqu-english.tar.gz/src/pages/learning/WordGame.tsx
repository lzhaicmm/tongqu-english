import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Volume2, RotateCcw, Check, X, Star, Trophy, Sparkles } from 'lucide-react';
import { mockWords } from '@/data/mockData';
import { speak, shuffle } from '@/utils';
import { useLearningStore } from '@/stores/learningStore';
import { useAuthStore } from '@/stores/authStore';

type GameMode = 'learn' | 'quiz' | 'result';

export default function WordGame() {
  const { lessonId } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated, addExp, addCoins } = useAuthStore();
  const { addRecord } = useLearningStore();

  const words = mockWords[lessonId] || mockWords['lesson-1-1'];
  const [mode, setMode] = useState<GameMode>('learn');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [quizWords, setQuizWords] = useState<typeof words>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);

  useEffect(() => {
    if (mode === 'quiz') {
      setQuizWords(shuffle(words).slice(0, Math.min(words.length, 5)));
      setCurrentIndex(0);
      setScore(0);
    }
  }, [mode]);

  useEffect(() => {
    if (mode === 'result' && isAuthenticated && user) {
      const exp = score * 10;
      const coins = score * 5;
      addExp(exp);
      addCoins(coins);
      addRecord({
        userId: user.id,
        lessonId: lessonId!,
        courseId: words[0]?.courseId || '',
        score: Math.round(score / Math.max(quizWords.length, 1) * 100),
        duration: 5,
      });
    }
  }, [mode]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🔒</div>
          <h2 className="text-xl font-bold mb-2">请先登录</h2>
          <Link to="/login" className="text-kids-blue hover:underline">去登录 →</Link>
        </div>
      </div>
    );
  }

  // Learn Mode
  if (mode === 'learn') {
    const currentWord = words[currentIndex];
    const progress = ((currentIndex + 1) / words.length) * 100;

    return (
      <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 py-8 px-4">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-gray-500 hover:text-kids-blue">
              <ArrowLeft size={20} /> 返回
            </button>
            <span className="text-sm text-gray-500">单词学习</span>
          </div>

          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex justify-between text-sm text-gray-500 mb-2">
              <span>学习进度</span>
              <span>{currentIndex + 1} / {words.length}</span>
            </div>
            <div className="h-3 bg-white rounded-full overflow-hidden shadow-inner">
              <div 
                className="h-full bg-gradient-to-r from-kids-blue to-kids-purple rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {/* Word Card */}
          <div 
            onClick={() => setIsFlipped(!isFlipped)}
            className="relative h-80 cursor-pointer perspective-1000"
            style={{ perspective: '1000px' }}
          >
            <div 
              className="relative w-full h-full transition-transform duration-700"
              style={{ 
                transformStyle: 'preserve-3d',
                transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)'
              }}
            >
              {/* Front - English */}
              <div 
                className="absolute w-full h-full bg-white rounded-3xl shadow-2xl flex flex-col items-center justify-center p-8"
                style={{ backfaceVisibility: 'hidden' }}
              >
                <div className="text-8xl mb-4">📖</div>
                <h2 className="text-5xl font-bold text-gray-800 mb-4">{currentWord.english}</h2>
                <p className="text-xl text-gray-400 mb-6">{currentWord.phonetic}</p>
                <button 
                  onClick={(e) => { e.stopPropagation(); speak(currentWord.english); }}
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-kids-blue to-kids-purple text-white rounded-full hover:shadow-lg hover:scale-105 transition-all"
                >
                  <Volume2 size={20} /> 听发音
                </button>
                <p className="text-sm text-gray-400 mt-4">👆 点击卡片看中文</p>
              </div>

              {/* Back - Chinese */}
              <div 
                className="absolute w-full h-full bg-gradient-to-br from-kids-purple to-kids-pink rounded-3xl shadow-2xl flex flex-col items-center justify-center p-8 text-white"
                style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}
              >
                <h2 className="text-5xl font-bold mb-6 text-shadow-kids">{currentWord.chinese}</h2>
                <div className="bg-white/20 backdrop-blur rounded-2xl p-4 max-w-sm text-center">
                  <p className="text-lg mb-1">
                    <span className="font-semibold">{currentWord.english}</span> - {currentWord.example}
                  </p>
                  <p className="text-white/80 text-sm">{currentWord.exampleTranslation}</p>
                </div>
                <p className="text-sm text-white/70 mt-4">👆 点击返回英文</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-between mt-8">
            <button
              disabled={currentIndex === 0}
              onClick={() => { setCurrentIndex(i => i - 1); setIsFlipped(false); }}
              className="px-6 py-3 bg-white rounded-xl shadow-md font-medium disabled:opacity-40 hover:shadow-lg transition-all"
            >
              ← 上一个
            </button>
            
            {currentIndex === words.length - 1 ? (
              <button
                onClick={() => setMode('quiz')}
                className="px-6 py-3 bg-gradient-to-r from-green-400 to-emerald-500 text-white font-bold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all flex items-center gap-2"
              >
                <Sparkles size={18} /> 开始测验
              </button>
            ) : (
              <button
                onClick={() => { setCurrentIndex(i => i + 1); setIsFlipped(false); }}
                className="px-6 py-3 bg-gradient-to-r from-kids-blue to-kids-purple text-white font-bold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all"
              >
                下一个 →
              </button>
            )}
          </div>

          {/* Tip */}
          <p className="text-center text-sm text-gray-400 mt-4">
            💡 小提示：点击卡片可以翻转，听一听发音，跟着读一遍吧！
          </p>
        </div>
      </div>
    );
  }

  // Quiz Mode
  if (mode === 'quiz') {
    const currentQ = quizWords[currentIndex];
    const allOptions = shuffle([
      currentQ.chinese,
      ...words.filter(w => w.chinese !== currentQ.chinese).slice(0, 3).map(w => w.chinese),
    ]);
    const correctIndex = allOptions.indexOf(currentQ.chinese);
    const quizProgress = ((currentIndex + 1) / quizWords.length) * 100;

    const handleSelect = (index: number) => {
      if (selectedAnswer !== null) return;
      setSelectedAnswer(index);
      if (index === correctIndex) {
        setScore(s => s + 1);
      } else {
        setWrongCount(w => w + 1);
      }
    };

    const handleNext = () => {
      if (currentIndex < quizWords.length - 1) {
        setCurrentIndex(i => i + 1);
        setSelectedAnswer(null);
      } else {
        setMode('result');
      }
    };

    return (
      <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 py-8 px-4">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-gray-500 hover:text-kids-blue">
              <ArrowLeft size={20} /> 返回
            </button>
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium text-green-600 bg-green-100 px-3 py-1 rounded-full">
                ✅ {score}
              </span>
              <span className="text-sm font-medium text-red-500 bg-red-100 px-3 py-1 rounded-full">
                ❌ {wrongCount}
              </span>
            </div>
          </div>

          {/* Progress */}
          <div className="mb-8">
            <div className="flex justify-between text-sm text-gray-500 mb-2">
              <span>小测验</span>
              <span>{currentIndex + 1} / {quizWords.length}</span>
            </div>
            <div className="h-3 bg-white rounded-full overflow-hidden shadow-inner">
              <div 
                className="h-full bg-gradient-to-r from-green-400 to-emerald-500 rounded-full transition-all duration-500"
                style={{ width: `${quizProgress}%` }}
              />
            </div>
          </div>

          {/* Question */}
          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <div className="text-center mb-8">
              <p className="text-sm text-gray-400 mb-2">这个单词的中文是？</p>
              <h2 className="text-5xl font-bold text-gray-800 mb-3">{currentQ.english}</h2>
              <button 
                onClick={() => speak(currentQ.english)}
                className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors"
              >
                <Volume2 size={18} /> 听发音
              </button>
            </div>

            {/* Options */}
            <div className="grid grid-cols-2 gap-4">
              {allOptions.map((option, i) => {
                let style = 'bg-gray-50 hover:bg-gray-100 border-gray-200 hover:border-kids-blue';
                if (selectedAnswer !== null) {
                  if (i === correctIndex) {
                    style = 'bg-green-50 border-green-500 text-green-700';
                  } else if (i === selectedAnswer) {
                    style = 'bg-red-50 border-red-500 text-red-700';
                  } else {
                    style = 'bg-gray-50 border-gray-200 opacity-50';
                  }
                }
                return (
                  <button
                    key={i}
                    onClick={() => handleSelect(i)}
                    disabled={selectedAnswer !== null}
                    className={`p-5 rounded-2xl border-2 font-semibold text-lg transition-all ${style}`}
                  >
                    {selectedAnswer !== null && i === correctIndex && <Check className="inline mr-2" size={20} />}
                    {selectedAnswer === i && i !== correctIndex && <X className="inline mr-2" size={20} />}
                    {option}
                  </button>
                );
              })}
            </div>

            {/* Next Button */}
            {selectedAnswer !== null && (
              <button
                onClick={handleNext}
                className="mt-6 w-full py-4 bg-gradient-to-r from-green-400 to-emerald-500 text-white font-bold text-lg rounded-2xl hover:shadow-lg transition-all flex items-center justify-center gap-2"
              >
                {currentIndex < quizWords.length - 1 ? '下一题 →' : '查看结果'}
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Result Mode
  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-yellow-50 via-orange-50 to-red-50 py-8 px-4 flex items-center">
      <div className="max-w-md mx-auto w-full">
        <div className="bg-white rounded-3xl shadow-2xl p-8 text-center">
          <div className="text-7xl mb-4">
            {score >= quizWords.length * 0.8 ? '🏆' : score >= quizWords.length * 0.6 ? '🎉' : '💪'}
          </div>
          <h2 className="text-3xl font-bold text-gray-800 mb-2">
            {score >= quizWords.length * 0.8 ? '太棒了！' : score >= quizWords.length * 0.6 ? '做得不错！' : '继续加油！'}
          </h2>
          <p className="text-gray-500 mb-6">
            答对 {score} 题，答错 {wrongCount} 题
          </p>

          {/* Score Circle */}
          <div className="relative w-40 h-40 mx-auto mb-6">
            <svg className="w-full h-full" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="45" fill="none" stroke="#E5E7EB" strokeWidth="8" />
              <circle 
                cx="50" cy="50" r="45" fill="none" 
                stroke="url(#gradient)" 
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={`${(score / quizWords.length) * 283} 283`}
                transform="rotate(-90 50 50)"
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#4F46E5" />
                  <stop offset="100%" stopColor="#EC4899" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold text-gray-800">
                {Math.round((score / quizWords.length) * 100)}%
              </span>
              <span className="text-xs text-gray-400">正确率</span>
            </div>
          </div>

          {/* Rewards */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="p-4 bg-purple-50 rounded-2xl">
              <div className="flex items-center justify-center gap-1 text-2xl mb-1">⭐</div>
              <div className="text-2xl font-bold text-purple-600">+{score * 10}</div>
              <div className="text-xs text-gray-500">经验值</div>
            </div>
            <div className="p-4 bg-yellow-50 rounded-2xl">
              <div className="flex items-center justify-center gap-1 text-2xl mb-1">🪙</div>
              <div className="text-2xl font-bold text-yellow-600">+{score * 5}</div>
              <div className="text-xs text-gray-500">金币</div>
            </div>
          </div>

          {/* Buttons */}
          <div className="space-y-3">
            <button
              onClick={() => { setMode('learn'); setCurrentIndex(0); }}
              className="w-full py-3 bg-gradient-to-r from-kids-blue to-kids-purple text-white font-semibold rounded-xl hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <RotateCcw size={18} /> 再学一次
            </button>
            <Link
              to="/dashboard"
              className="w-full py-3 bg-gray-100 text-gray-700 font-semibold rounded-xl hover:bg-gray-200 transition-all block text-center"
            >
              返回学习中心
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
