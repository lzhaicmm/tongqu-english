import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, Star, Clock, Users, ChevronRight, Flame, Mic, MessageCircle } from 'lucide-react';
import { conversationScenes, difficultyNames, difficultyColors } from '@/data/conversationScenes';
import type { Difficulty } from '@/types';

type DifficultyFilter = Difficulty | 'all';
type TagFilter = string | 'all';

export default function SceneSelect() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState<DifficultyFilter>('all');
  const [selectedTag, setSelectedTag] = useState<TagFilter>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'featured'>('featured');

  const allTags = Array.from(new Set(conversationScenes.flatMap(s => s.tags)));

  const filteredScenes = conversationScenes.filter(scene => {
    const matchesSearch = 
      scene.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scene.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scene.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesDifficulty = selectedDifficulty === 'all' || scene.difficulty === selectedDifficulty;
    const matchesTag = selectedTag === 'all' || scene.tags.includes(selectedTag);
    return matchesSearch && matchesDifficulty && matchesTag;
  });

  const featuredScenes = filteredScenes.slice(0, 4);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Hero Banner */}
      <div className="bg-gradient-to-br from-kids-pink via-rose-500 to-kids-purple rounded-3xl p-8 text-white mb-8 shadow-xl relative overflow-hidden">
        <div className="absolute inset-0 opacity-15">
          {['🎤', '💬', '🎯', '🌟', '✨', '🗣️'].map((e, i) => (
            <span key={i} className="absolute text-5xl" style={{ top: `${5 + i * 15}%`, right: `${60 - i * 10}%` }}>
              {e}
            </span>
          ))}
        </div>
        <div className="relative">
          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-1.5 rounded-full text-sm mb-4">
            <Mic size={14} /> 全新功能 · 口语对话场景
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-shadow-kids">
            和 AI 真人般对话练口语
          </h1>
          <p className="text-white/90 max-w-2xl mb-4">
            8 个真实生活场景，从自我介绍到餐厅点餐、问路、看病……
            每一场对话都是沉浸式口语实战！
          </p>
          <div className="flex flex-wrap gap-3 text-sm">
            <div className="flex items-center gap-1.5 bg-white/20 backdrop-blur-sm px-3 py-1.5 rounded-full">
              <MessageCircle size={14} /> {conversationScenes.length} 个场景
            </div>
            <div className="flex items-center gap-1.5 bg-white/20 backdrop-blur-sm px-3 py-1.5 rounded-full">
              <Flame size={14} /> 多轮对话互动
            </div>
            <div className="flex items-center gap-1.5 bg-white/20 backdrop-blur-sm px-3 py-1.5 rounded-full">
              <Star size={14} className="fill-yellow-300 text-yellow-300" /> 关键词智能评分
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl shadow-sm p-5 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索场景、关键词..."
              className="w-full pl-11 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-kids-pink/50"
            />
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-3 mt-4">
          {/* Difficulty */}
          <div className="flex items-center gap-2">
            <Filter size={14} className="text-gray-400" />
            <span className="text-sm text-gray-500 font-medium">难度：</span>
            <div className="flex gap-2">
              {(['all', 'easy', 'medium', 'hard'] as const).map(d => (
                <button
                  key={d}
                  onClick={() => setSelectedDifficulty(d)}
                  className={`px-3 py-1 rounded-lg text-sm font-medium transition-all ${
                    selectedDifficulty === d
                      ? 'bg-kids-pink text-white shadow-sm'
                      : d === 'all'
                        ? 'bg-gray-100 text-gray-600'
                        : difficultyColors[d as Difficulty]
                  }`}
                >
                  {d === 'all' ? '全部' : difficultyNames[d]}
                </button>
              ))}
            </div>
          </div>

          {/* Tags */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm text-gray-500 font-medium">标签：</span>
            <button
              onClick={() => setSelectedTag('all')}
              className={`px-3 py-1 rounded-lg text-sm font-medium transition-all ${
                selectedTag === 'all'
                  ? 'bg-kids-pink text-white shadow-sm'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              全部
            </button>
            {allTags.map(tag => (
              <button
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`px-3 py-1 rounded-lg text-sm font-medium transition-all ${
                  selectedTag === tag
                    ? 'bg-kids-pink text-white shadow-sm'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                #{tag}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Featured Row */}
      {viewMode === 'featured' && featuredScenes.length > 0 && (
        <>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
              <Star size={20} className="text-yellow-500 fill-yellow-500" />
              精选推荐
            </h2>
            <button
              onClick={() => setViewMode('grid')}
              className="text-sm text-kids-pink font-medium hover:underline"
            >
              查看全部 →
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10">
            {featuredScenes.map(scene => (
              <SceneFeaturedCard key={scene.id} scene={scene} />
            ))}
          </div>
        </>
      )}

      {/* All Scenes Grid */}
      <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
        🎯 {viewMode === 'featured' ? '全部场景' : '全部场景'}
        <span className="text-sm font-normal text-gray-400">({filteredScenes.length} 个)</span>
      </h2>

      {filteredScenes.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {filteredScenes.map(scene => (
            <SceneCard key={scene.id} scene={scene} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-2xl">
          <div className="text-6xl mb-4">🔍</div>
          <h3 className="text-xl font-semibold text-gray-700 mb-2">没有找到匹配的场景</h3>
          <p className="text-gray-500">试试调整搜索关键词或筛选条件</p>
        </div>
      )}
    </div>
  );
}

function SceneCard({ scene }: { scene: typeof conversationScenes[0] }) {
  return (
    <Link
      to={`/conversation/${scene.id}`}
      className="group bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all card-hover overflow-hidden"
    >
      {/* Icon */}
      <div className={`${scene.emojiBg} h-28 flex items-center justify-center relative overflow-hidden`}>
        <span className="text-6xl group-hover:scale-110 transition-transform">{scene.icon}</span>
        <div className="absolute top-2 right-2">
          <span className={`px-2 py-0.5 text-xs font-bold rounded-lg border ${difficultyColors[scene.difficulty]}`}>
            {difficultyNames[scene.difficulty]}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="font-bold text-gray-800 mb-0.5 group-hover:text-kids-pink transition-colors">
          {scene.title}
        </h3>
        <p className="text-xs text-gray-500 mb-3">{scene.subtitle}</p>

        <div className="flex items-center justify-between text-xs text-gray-400">
          <div className="flex items-center gap-1">
            <Clock size={11} /> {scene.duration}分钟
          </div>
          <div className="flex items-center gap-1">
            <MessageCircle size={11} /> {scene.turns}轮
          </div>
          <div className="flex items-center gap-1">
            <Users size={11} /> {scene.gradeRange}
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1 mt-2">
          {scene.tags.slice(0, 2).map(tag => (
            <span key={tag} className="px-2 py-0.5 bg-gray-100 text-gray-500 rounded text-[10px]">
              #{tag}
            </span>
          ))}
        </div>
      </div>
    </Link>
  );
}

function SceneFeaturedCard({ scene }: { scene: typeof conversationScenes[0] }) {
  return (
    <Link
      to={`/conversation/${scene.id}`}
      className="group bg-white rounded-2xl shadow-md hover:shadow-xl transition-all overflow-hidden card-hover flex"
    >
      {/* Icon Side */}
      <div className={`${scene.emojiBg} w-32 flex flex-col items-center justify-center p-4 text-white relative`}>
        <span className="text-5xl group-hover:scale-110 transition-transform">{scene.icon}</span>
        <span className="text-xs mt-2 opacity-80">{scene.gradeRange}</span>
      </div>

      {/* Content Side */}
      <div className="flex-1 p-5 flex flex-col">
        <div className="flex items-center gap-2 mb-1">
          <span className={`px-2 py-0.5 text-xs font-bold rounded-md border ${difficultyColors[scene.difficulty]}`}>
            {difficultyNames[scene.difficulty]}
          </span>
          <span className="text-xs text-gray-400">{scene.turns} 轮对话</span>
        </div>
        <h3 className="text-lg font-bold text-gray-800 mb-1 group-hover:text-kids-pink transition-colors">
          {scene.title}
        </h3>
        <p className="text-sm text-gray-500 mb-3 flex-1">{scene.opening}</p>

        <div className="flex items-center justify-between">
          <div className="flex gap-1">
            {scene.tags.slice(0, 3).map(tag => (
              <span key={tag} className="px-2 py-0.5 bg-kids-pink/10 text-kids-pink rounded-md text-xs">
                #{tag}
              </span>
            ))}
          </div>
          <div className="flex items-center gap-1 text-kids-pink font-medium text-sm">
            开始 <ChevronRight size={14} />
          </div>
        </div>
      </div>
    </Link>
  );
}
