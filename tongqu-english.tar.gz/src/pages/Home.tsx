import { Link } from 'react-router-dom';
import { Play, Star, Users, Clock, Award, Target, Sparkles, BookOpen, BarChart3, MessageCircle, ChevronRight } from 'lucide-react';
import { mockCourses, mockLearningPaths } from '@/data/mockData';
import { levelNames } from '@/utils';

export default function Home() {
  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-kids-blue via-kids-purple to-kids-pink text-white py-20 lg:py-32">
        {/* Decorative elements */}
        <div className="absolute inset-0 overflow-hidden">
          {['⭐', '🌟', '✨', '🎈', '🎨', '📚', '🌈', '🦋'].map((emoji, i) => (
            <div
              key={i}
              className="absolute text-3xl md:text-5xl opacity-20 animate-bounce-slow"
              style={{
                top: `${10 + Math.random() * 80}%`,
                left: `${5 + Math.random() * 90}%`,
                animationDelay: `${i * 0.3}s`,
                animationDuration: `${2 + Math.random() * 2}s`,
              }}
            >
              {emoji}
            </div>
          ))}
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm mb-6">
            <Sparkles size={16} />
            <span>已服务 10万+ 小朋友</span>
          </div>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 text-shadow-kids leading-tight">
            让孩子爱上<span className="text-yellow-300">英语</span>
            <br />
            <span className="text-2xl md:text-4xl font-normal">从此刻开始 🚀</span>
          </h1>
          <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto mb-10">
            专为中国小学生打造的沉浸式英语学习平台，趣味互动、科学分级、个性推荐，
            让每一个孩子都能自信地说英语！
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/register"
              className="w-full sm:w-auto px-8 py-4 bg-white text-kids-blue font-bold text-lg rounded-2xl shadow-xl hover:shadow-2xl hover:scale-105 transition-all flex items-center justify-center gap-2"
            >
              <Play size={22} fill="currentColor" />
              免费开始学习
            </Link>
            <Link
              to="/courses"
              className="w-full sm:w-auto px-8 py-4 bg-white/20 backdrop-blur-sm text-white font-bold text-lg rounded-2xl border-2 border-white/30 hover:bg-white/30 transition-all flex items-center justify-center gap-2"
            >
              浏览课程
              <ChevronRight size={20} />
            </Link>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 max-w-4xl mx-auto">
            {[
              { icon: Users, value: '10万+', label: '活跃学员' },
              { icon: BookOpen, value: '1000+', label: '精品课程' },
              { icon: Star, value: '4.9', label: '平均评分' },
              { icon: Clock, value: '500万+', label: '学习次数' },
            ].map((stat, i) => (
              <div key={i} className="bg-white/15 backdrop-blur-sm rounded-2xl p-4">
                <stat.icon size={28} className="mx-auto mb-2" />
                <div className="text-2xl md:text-3xl font-bold">{stat.value}</div>
                <div className="text-sm text-white/80">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              为什么选择<span className="text-kids-blue">童趣英语</span>？
            </h2>
            <p className="text-gray-500 text-lg">六大核心功能，打造沉浸式英语学习体验</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: '🎯',
                title: '分级课程体系',
                desc: '启蒙到高级四个等级，精准匹配孩子当前水平，循序渐进',
                color: 'from-blue-400 to-blue-600',
              },
              {
                icon: '🎮',
                title: '互动式学习',
                desc: '单词卡片、语法练习、口语跟读、听力训练，边玩边学',
                color: 'from-pink-400 to-pink-600',
              },
              {
                icon: '📊',
                title: '进度实时追踪',
                desc: '可视化学习数据，每日目标、连续打卡、能力图谱一目了然',
                color: 'from-green-400 to-green-600',
              },
              {
                icon: '👤',
                title: '个性化推荐',
                desc: '根据测评结果智能推荐最适合的学习路径',
                color: 'from-orange-400 to-orange-600',
              },
              {
                icon: '🏆',
                title: '成就激励系统',
                desc: '金币、徽章、排行榜，游戏化机制让学习更有动力',
                color: 'from-purple-400 to-purple-600',
              },
              {
                icon: '👨‍👩‍👧',
                title: '家长社区',
                desc: '家长交流、老师答疑、资源分享，共同见证孩子成长',
                color: 'from-teal-400 to-teal-600',
              },
            ].map((feature, i) => (
              <div
                key={i}
                className="group p-6 rounded-2xl bg-gradient-to-br from-gray-50 to-white border border-gray-100 card-hover"
              >
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition-transform`}>
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">{feature.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Courses */}
      <section className="py-20 bg-gradient-to-b from-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
                精选分级课程
              </h2>
              <p className="text-gray-500">覆盖1-6年级，总有一款适合你的孩子</p>
            </div>
            <Link
              to="/courses"
              className="hidden md:flex items-center gap-1 text-kids-blue font-medium hover:gap-2 transition-all"
            >
              查看全部 <ChevronRight size={18} />
            </Link>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {mockCourses.slice(0, 4).map((course) => (
              <Link
                key={course.id}
                to={`/courses/${course.id}`}
                className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all card-hover"
              >
                <div className={`h-32 bg-gradient-to-br from-${course.color} to-${course.color === 'kids-blue' ? 'kids-purple' : 'kids-pink'} flex items-center justify-center`}>
                  <span className="text-6xl group-hover:scale-110 transition-transform">{course.icon}</span>
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs px-2 py-0.5 bg-kids-blue/10 text-kids-blue rounded-full font-medium">
                      {levelNames[course.level]}
                    </span>
                    <span className="text-xs text-gray-400">{course.gradeRange}</span>
                  </div>
                  <h3 className="font-bold text-gray-800 mb-2 group-hover:text-kids-blue transition-colors">
                    {course.title}
                  </h3>
                  <p className="text-gray-500 text-sm mb-4 line-clamp-2">{course.description}</p>
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <div className="flex items-center gap-1">
                      <Clock size={12} /> {course.totalLessons}节课
                    </div>
                    <div className="flex items-center gap-1">
                      <Star size={12} className="text-yellow-400 fill-yellow-400" />
                      {course.rating}
                    </div>
                    <div className="flex items-center gap-1">
                      <Users size={12} />
                      {course.studentsCount > 1000 
                        ? `${(course.studentsCount / 1000).toFixed(1)}k` 
                        : course.studentsCount}
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Learning Paths */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4 flex items-center justify-center gap-3">
              <Target className="text-kids-blue" size={36} />
              推荐学习路径
            </h2>
            <p className="text-gray-500 text-lg">AI智能推荐，制定专属学习计划</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {mockLearningPaths.map((path, i) => {
              const colors = [
                'from-yellow-400 to-orange-500',
                'from-pink-400 to-rose-500',
                'from-purple-400 to-violet-500',
                'from-blue-400 to-indigo-500',
              ];
              return (
                <div
                  key={path.id}
                  className={`relative p-6 rounded-2xl bg-gradient-to-br ${colors[i]} text-white shadow-lg card-hover`}
                >
                  <div className="absolute top-4 right-4 text-5xl opacity-20 font-bold">
                    {i + 1}
                  </div>
                  <Award size={32} className="mb-4" />
                  <h3 className="text-xl font-bold mb-2">{path.title}</h3>
                  <p className="text-white/80 text-sm mb-4">{path.description}</p>
                  <div className="flex items-center gap-2 text-sm bg-white/20 rounded-lg px-3 py-2">
                    <Clock size={14} />
                    <span>约 {path.estimatedWeeks} 周完成</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            准备好开始英语之旅了吗？
          </h2>
          <p className="text-xl text-gray-300 mb-10">
            注册即可免费体验全部启蒙课程，还有精美学习礼包等着你！
          </p>
          <Link
            to="/register"
            className="inline-block px-10 py-4 bg-gradient-to-r from-kids-blue to-kids-purple text-white font-bold text-lg rounded-2xl shadow-2xl hover:shadow-kids-blue/30 hover:scale-105 transition-all"
          >
            立即免费注册 →
          </Link>
          <div className="flex items-center justify-center gap-6 mt-8 text-sm text-gray-400">
            <span className="flex items-center gap-1">✓ 免费试听所有课程</span>
            <span className="hidden sm:flex items-center gap-1">✓ 随时取消</span>
            <span className="flex items-center gap-1">✓ 专业师资团队</span>
          </div>
        </div>
      </section>
    </div>
  );
}
