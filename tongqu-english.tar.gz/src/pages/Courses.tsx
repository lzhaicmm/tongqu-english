import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Star, Users, Clock, Filter, ChevronRight } from 'lucide-react';
import { mockCourses } from '@/data/mockData';
import { levelNames } from '@/utils';
import type { CourseLevel } from '@/types';

const levelFilters: { value: CourseLevel | 'all'; label: string; color: string }[] = [
  { value: 'all', label: '全部', color: 'bg-gray-100 text-gray-600' },
  { value: 'starter', label: '启蒙级', color: 'bg-yellow-100 text-yellow-700' },
  { value: 'elementary', label: '初级', color: 'bg-pink-100 text-pink-700' },
  { value: 'intermediate', label: '中级', color: 'bg-purple-100 text-purple-700' },
  { value: 'advanced', label: '高级', color: 'bg-blue-100 text-blue-700' },
];

export default function Courses() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<CourseLevel | 'all'>('all');

  const filteredCourses = mockCourses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          course.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLevel = selectedLevel === 'all' || course.level === selectedLevel;
    return matchesSearch && matchesLevel;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 bg-gradient-to-br from-kids-blue to-kids-purple rounded-xl flex items-center justify-center text-2xl">
            📚
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">课程中心</h1>
            <p className="text-gray-500">科学分级，找到最适合的课程</p>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-2xl p-6 shadow-sm mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="relative flex-1">
            <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索课程名称或关键词..."
              className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-kids-blue/50 focus:border-kids-blue transition-all"
            />
          </div>

          {/* Filters */}
          <div className="flex items-center gap-2">
            <Filter size={18} className="text-gray-400" />
            <div className="flex flex-wrap gap-2">
              {levelFilters.map(filter => (
                <button
                  key={filter.value}
                  onClick={() => setSelectedLevel(filter.value)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                    selectedLevel === filter.value
                      ? 'bg-kids-blue text-white shadow-md'
                      : filter.color + ' hover:shadow-sm'
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Level Guide */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-6 mb-8">
        <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
          🎯 如何选择合适的级别？
        </h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
          <div className="p-3 bg-white rounded-xl">
            <div className="font-semibold text-yellow-600 mb-1">🌟 启蒙级</div>
            <p className="text-gray-500">适合零基础，1-2年级</p>
          </div>
          <div className="p-3 bg-white rounded-xl">
            <div className="font-semibold text-pink-600 mb-1">🌈 初级</div>
            <p className="text-gray-500">会少量单词，2-3年级</p>
          </div>
          <div className="p-3 bg-white rounded-xl">
            <div className="font-semibold text-purple-600 mb-1">🚀 中级</div>
            <p className="text-gray-500">会简单对话，4-5年级</p>
          </div>
          <div className="p-3 bg-white rounded-xl">
            <div className="font-semibold text-blue-600 mb-1">🏆 高级</div>
            <p className="text-gray-500">语法基础，5-6年级</p>
          </div>
        </div>
      </div>

      {/* Course Grid */}
      {filteredCourses.length > 0 ? (
        <div className="grid md:grid-cols-2 gap-6">
          {filteredCourses.map(course => (
            <Link
              key={course.id}
              to={`/courses/${course.id}`}
              className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all card-hover"
            >
              <div className="flex">
                {/* Course Icon */}
                <div className={`w-32 h-full flex items-center justify-center bg-gradient-to-br from-${course.color} to-${course.color === 'kids-blue' ? 'kids-purple' : 'kids-pink'} flex-shrink-0`}>
                  <span className="text-5xl group-hover:scale-110 transition-transform">{course.icon}</span>
                </div>
                
                {/* Content */}
                <div className="flex-1 p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs px-2 py-0.5 bg-kids-blue/10 text-kids-blue rounded-full font-medium">
                      {levelNames[course.level]}
                    </span>
                    <span className="text-xs text-gray-400">{course.gradeRange}</span>
                  </div>
                  <h3 className="font-bold text-gray-800 mb-1 group-hover:text-kids-blue transition-colors">
                    {course.title}
                  </h3>
                  <p className="text-gray-500 text-sm mb-3 line-clamp-2">{course.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 text-xs text-gray-400">
                      <div className="flex items-center gap-1">
                        <Clock size={12} /> {course.totalLessons}节课
                      </div>
                      <div className="flex items-center gap-1">
                        <Star size={12} className="text-yellow-400 fill-yellow-400" />
                        {course.rating}
                      </div>
                      <div className="flex items-center gap-1">
                        <Users size={12} />
                        {course.studentsCount > 1000 
                          ? `${(course.studentsCount / 1000).toFixed(1)}k` 
                          : course.studentsCount}
                      </div>
                    </div>
                    <ChevronRight size={18} className="text-gray-300 group-hover:text-kids-blue group-hover:translate-x-1 transition-all" />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-2xl">
          <div className="text-6xl mb-4">🔍</div>
          <h3 className="text-xl font-semibold text-gray-700 mb-2">没有找到匹配的课程</h3>
          <p className="text-gray-500">试试调整搜索关键词或筛选条件</p>
        </div>
      )}
    </div>
  );
}
