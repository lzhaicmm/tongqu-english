import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, BookOpen, Pen, Mic, Headphones, MessageCircle } from 'lucide-react';
import { mockCourses } from '@/data/mockData';

export default function Learning() {
  const { lessonId } = useParams();
  
  // Find which course this lesson belongs to
  let course = null;
  let lesson = null;
  for (const c of mockCourses) {
    const foundLesson = c.lessons.find(l => l.id === lessonId);
    if (foundLesson) {
      course = c;
      lesson = foundLesson;
      break;
    }
  }

  if (!lesson || !course) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <div className="text-6xl mb-4">😕</div>
        <h1 className="text-2xl font-bold mb-2">课时未找到</h1>
        <Link to="/courses" className="text-kids-blue hover:underline">返回课程列表</Link>
      </div>
    );
  }

  const learningModes = [
    {
      type: 'vocabulary',
      icon: BookOpen,
      label: '单词记忆',
      desc: '卡片式学习，翻转查看释义',
      color: 'from-blue-400 to-cyan-500',
      path: `/learn/word/${lesson.id}`,
    },
    {
      type: 'grammar',
      icon: Pen,
      label: '语法练习',
      desc: '选择题巩固语法知识',
      color: 'from-purple-400 to-indigo-500',
      path: `/learn/grammar/${lesson.id}`,
    },
    {
      type: 'speaking',
      icon: Mic,
      label: '口语跟读',
      desc: '跟着标准发音练习朗读',
      color: 'from-pink-400 to-rose-500',
      path: `/learn/speaking/${lesson.id}`,
    },
    {
      type: 'listening',
      icon: Headphones,
      label: '听力训练',
      desc: '听音理解，回答问题',
      color: 'from-teal-400 to-cyan-500',
      path: `/learn/listening/${lesson.id}`,
    },
    {
      type: 'conversation',
      icon: MessageCircle,
      label: '场景对话',
      desc: '真实场景 AI 对话练口语',
      color: 'from-pink-400 via-rose-400 to-orange-500',
      path: `/conversation`,
    },
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-gray-50 to-blue-50 py-8 px-4">
      <div className="max-w-3xl mx-auto">
        {/* Back */}
        <Link 
          to={`/courses/${course.id}`} 
          className="inline-flex items-center gap-2 text-gray-500 hover:text-kids-blue mb-6"
        >
          <ArrowLeft size={20} /> 返回课程详情
        </Link>

        {/* Lesson Info */}
        <div className="bg-white rounded-3xl shadow-xl p-8 mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-kids-blue to-kids-purple rounded-2xl flex items-center justify-center text-3xl">
              {course.icon}
            </div>
            <div>
              <p className="text-sm text-gray-400">{course.title}</p>
              <h1 className="text-2xl font-bold text-gray-800">{lesson.title}</h1>
            </div>
          </div>
          <div className="flex items-center gap-4 text-sm text-gray-500">
            <span>⏱️ {lesson.duration}分钟</span>
            <span>•</span>
            <span>第 {lesson.order} 课</span>
            <span>•</span>
            <span className="px-2 py-0.5 bg-kids-blue/10 text-kids-blue rounded-full text-xs">
              {lesson.type === 'vocabulary' ? '词汇课' : 
               lesson.type === 'grammar' ? '语法课' :
               lesson.type === 'speaking' ? '口语课' : '听力课'}
            </span>
          </div>
        </div>

        {/* Learning Mode Selection */}
        <h2 className="text-lg font-bold text-gray-800 mb-4">选择学习方式</h2>
        <div className="grid grid-cols-2 gap-4">
          {learningModes.map(mode => (
            <Link
              key={mode.type}
              to={mode.path}
              className={`bg-gradient-to-br ${mode.color} text-white rounded-2xl p-6 hover:shadow-xl hover:scale-105 transition-all`}
            >
              <mode.icon size={32} className="mb-3" />
              <h3 className="font-bold text-lg mb-1">{mode.label}</h3>
              <p className="text-white/80 text-sm">{mode.desc}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
