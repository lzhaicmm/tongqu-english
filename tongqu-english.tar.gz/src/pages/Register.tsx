import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, User, Eye, EyeOff, ArrowLeft, AlertCircle, GraduationCap } from 'lucide-react';
import { useAuthStore } from '@/stores/authStore';
import { gradeMap } from '@/utils';

export default function Register() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [grade, setGrade] = useState('3');
  const [showPassword, setShowPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { register } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!agreeTerms) {
      setError('请先阅读并同意用户协议和隐私政策');
      return;
    }
    if (password !== confirmPassword) {
      setError('两次输入的密码不一致');
      return;
    }
    if (password.length < 6) {
      setError('密码至少需要6位字符');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      const result = register(username, email, password, grade);
      if (result.success) {
        navigate('/dashboard');
      } else {
        setError(result.message);
      }
      setLoading(false);
    }, 500);
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gradient-to-br from-kids-pink/10 via-purple-50 to-kids-blue/10 py-12 px-4">
      <div className="w-full max-w-lg">
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-br from-kids-pink to-kids-purple p-8 text-center text-white relative overflow-hidden">
            <div className="absolute inset-0 opacity-10">
              {['🎈', '🎨', '📚', '🦋'].map((e, i) => (
                <span
                  key={i}
                  className="absolute text-4xl"
                  style={{ top: `${15 + i * 20}%`, left: `${15 + i * 22}%` }}
                >
                  {e}
                </span>
              ))}
            </div>
            <div className="relative">
              <Link to="/" className="inline-flex items-center gap-2 text-white/80 hover:text-white text-sm mb-6">
                <ArrowLeft size={16} /> 返回首页
              </Link>
              <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full mx-auto flex items-center justify-center text-5xl mb-4">
                🌟
              </div>
              <h1 className="text-2xl font-bold mb-1">开启英语之旅！</h1>
              <p className="text-white/80 text-sm">注册即送免费学习礼包</p>
            </div>
          </div>

          {/* Form */}
          <div className="p-8">
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="flex items-center gap-2 p-3 bg-red-50 text-red-600 rounded-xl text-sm">
                  <AlertCircle size={18} />
                  {error}
                </div>
              )}

              {/* Username */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  孩子的昵称 <span className="text-gray-400 text-xs">(将作为用户名显示)</span>
                </label>
                <div className="relative">
                  <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="如：小明、豆豆..."
                    className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-kids-purple/50 focus:border-kids-purple transition-all"
                  />
                </div>
              </div>

              {/* Grade */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <GraduationCap size={14} className="inline mr-1" />
                  当前年级
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {Object.entries(gradeMap).map(([key, name]) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setGrade(key)}
                      className={`py-2.5 rounded-xl font-medium text-sm transition-all ${
                        grade === key
                          ? 'bg-gradient-to-r from-kids-pink to-kids-purple text-white shadow-md'
                          : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      {name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">家长邮箱</label>
                <div className="relative">
                  <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="用于接收学习报告"
                    className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-kids-purple/50 focus:border-kids-purple transition-all"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">密码</label>
                  <div className="relative">
                    <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="至少6位"
                      className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-kids-purple/50 focus:border-kids-purple transition-all"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">确认密码</label>
                  <div className="relative">
                    <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="再输一次"
                      className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-kids-purple/50 focus:border-kids-purple transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Terms */}
              <label className="flex items-start gap-2 text-sm text-gray-600 cursor-pointer">
                <input
                  type="checkbox"
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="w-4 h-4 text-kids-purple rounded mt-0.5"
                />
                <span>
                  我已阅读并同意 <a href="#" className="text-kids-purple hover:underline">用户协议</a> 和 <a href="#" className="text-kids-purple hover:underline">隐私政策</a>
                </span>
              </label>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-gradient-to-r from-kids-pink to-kids-purple text-white font-semibold rounded-xl hover:shadow-lg hover:scale-[1.02] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? '注册中...' : '🎁 免费注册，领取礼包'}
              </button>
            </form>

            <p className="text-center text-sm text-gray-500 mt-6">
              已有账号？
              <Link to="/login" className="text-kids-purple font-medium hover:underline ml-1">
                立即登录 →
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
