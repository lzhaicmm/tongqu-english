import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Play, Pause, Volume2, Mic, Square, Send, Eye, EyeOff,
  RotateCcw, Sparkles, Star, CheckCircle, AlertCircle, Heart, BookOpen,
  Lightbulb, ChevronRight, MessageCircle
} from 'lucide-react';
import { conversationScenes } from '@/data/conversationScenes';
import { useAuthStore } from '@/stores/authStore';
import { useLearningStore } from '@/stores/learningStore';
import type { ChatBubble, DialogueLine, Role } from '@/types';

export default function ConversationPractice() {
  const { sceneId } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated, addExp, addCoins } = useAuthStore();
  const { addRecord } = useLearningStore();

  const scene = conversationScenes.find(s => s.id === sceneId);

  // Dialog flow state
  const [stepIndex, setStepIndex] = useState(0);        // 当前 dialogue index
  const [bubbles, setBubbles] = useState<ChatBubble[]>([]);
  const [isUserTurn, setIsUserTurn] = useState(false);
  const [userInput, setUserInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [showChinese, setShowChinese] = useState(true);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [showVocabulary, setShowVocabulary] = useState(false);
  const [showTips, setShowTips] = useState(false);
  const [score, setScore] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [userAttempts, setUserAttempts] = useState(0);   // 当前步骤已尝试次数
  const [turnScores, setTurnScores] = useState<number[]>([]);
  const [completed, setCompleted] = useState(false);

  const chatContainerRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const autoSpeakTimerRef = useRef<number | null>(null);

  // Initialize speech recognition
  useEffect(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SR) {
      const rec = new SR();
      rec.lang = 'en-US';
      rec.continuous = false;
      rec.interimResults = false;

      rec.onresult = (e: any) => {
        const transcript = e.results[0][0].transcript.trim();
        setUserInput(transcript);
        setIsRecording(false);
        // auto-submit after a short delay
        setTimeout(() => handleSubmitUserInput(transcript), 300);
      };
      rec.onerror = () => setIsRecording(false);
      rec.onend = () => setIsRecording(false);

      recognitionRef.current = rec;
    }
    return () => {
      if (autoSpeakTimerRef.current) window.clearTimeout(autoSpeakTimerRef.current);
    };
  }, []);

  // Auto-scroll when bubble list changes
  useEffect(() => {
    chatContainerRef.current?.scrollTo({
      top: chatContainerRef.current.scrollHeight,
      behavior: 'smooth',
    });
  }, [bubbles]);

  // Initialize scene (when scene loads or restart)
  const initScene = useCallback(() => {
    if (!scene) return;
    setBubbles([]);
    setStepIndex(0);
    setScore(0);
    setCorrectCount(0);
    setTurnScores([]);
    setCompleted(false);
    setUserAttempts(0);
    setUserInput('');

    // Show opening system bubble
    const openingBubble: ChatBubble = {
      id: 'opening',
      role: 'assistant',
      english: scene.opening,
      timestamp: Date.now(),
      isSystem: true,
    };
    setBubbles([openingBubble]);

    // Push first assistant line
    setTimeout(() => {
      pushAssistantDialogue(0);
    }, 1000);
  }, [scene]);

  useEffect(() => {
    initScene();
  }, [initScene]);

  if (!scene) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <div className="text-6xl mb-4">😕</div>
        <h1 className="text-2xl font-bold mb-2">场景不存在</h1>
        <Link to="/conversation" className="text-kids-pink hover:underline">返回场景列表</Link>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🔒</div>
          <h2 className="text-xl font-bold mb-2">请先登录才能对话</h2>
          <Link to="/login" className="text-kids-pink hover:underline">去登录 →</Link>
        </div>
      </div>
    );
  }

  // ========== Audio playback ==========
  const speakText = (text: string) => {
    if (isPlayingAudio) return;
    setIsPlayingAudio(true);
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'en-US';
      u.rate = 0.85;
      u.pitch = 1;
      u.onend = () => setIsPlayingAudio(false);
      window.speechSynthesis.speak(u);
    } else {
      setTimeout(() => setIsPlayingAudio(false), 1200);
    }
  };

  // ========== Push assistant line ==========
  const pushAssistantDialogue = (idx: number) => {
    const line = scene.dialogues[idx];
    if (!line) return;
    if (line.isUser) return; // should not happen, but guard

    const bubble: ChatBubble = {
      id: line.id,
      role: line.role,
      english: line.english,
      chinese: line.chinese,
      timestamp: Date.now(),
    };
    setBubbles(prev => [...prev, bubble]);

    // Play audio
    speakText(line.english);

    // Find next user line or complete
    setTimeout(() => {
      findNextUserTurn(idx + 1);
    }, 800);
  };

  // ========== Find next user turn, if next step is also assistant, push it after a pause ==========
  const findNextUserTurn = (fromIndex: number) => {
    const next = scene.dialogues[fromIndex];
    if (!next) {
      finishScene();
      return;
    }
    if (next.isUser) {
      setIsUserTurn(true);
      setStepIndex(fromIndex);
      setUserAttempts(0);
    } else {
      // another assistant line — push it
      pushAssistantDialogue(fromIndex);
    }
  };

  // ========== Submit user input (voice or text) ==========
  const handleSubmitUserInput = async (input: string) => {
    if (!isUserTurn || !input.trim()) return;
    const currentLine = scene.dialogues[stepIndex];
    if (!currentLine || !currentLine.isUser) return;

    const cleanInput = input.trim();
    setIsUserTurn(false);
    setUserInput('');
    const newAttempts = userAttempts + 1;
    setUserAttempts(newAttempts);

    // Evaluate
    const evalResult = evaluateAnswer(cleanInput, currentLine);
    setTurnScores(prev => [...prev, evalResult.score]);

    // Push user bubble (attempt)
    const userBubble: ChatBubble = {
      id: `user-attempt-${Date.now()}`,
      role: 'user',
      english: cleanInput,
      timestamp: Date.now(),
      isUserAttempt: true,
      score: evalResult.score,
      feedback: evalResult.feedback,
    };
    setBubbles(prev => [...prev, userBubble]);

    // Update totals
    setScore(s => s + evalResult.score);
    if (evalResult.isCorrect) setCorrectCount(c => c + 1);

    // Show reference if not good enough and attempts >= 1
    if (!evalResult.isCorrect && newAttempts >= 2) {
      pushReferenceBubble(currentLine);
      // After showing reference, let them try once more — OR advance
      setTimeout(() => {
        advanceToNextTurn(currentLine);
      }, 1500);
      return;
    }

    // Good enough — advance
    if (evalResult.isCorrect || evalResult.score >= 60) {
      setTimeout(() => {
        advanceToNextTurn(currentLine);
      }, 1000);
    } else {
      // Not good, give another chance
      setIsUserTurn(true);
      // Show the system tip bubble
      const tipBubble: ChatBubble = {
        id: `tip-${Date.now()}`,
        role: 'assistant',
        english: 'Try again! Listen to the reference first if you want.',
        chinese: '再试一次吧！需要的话先听一下参考。',
        timestamp: Date.now(),
        isSystem: true,
      };
      setBubbles(prev => [...prev, tipBubble]);
    }
  };

  const advanceToNextTurn = (currentLine: DialogueLine) => {
    const nextIdx = stepIndex + 1;
    // After user responds, assistant always responds (the next non-user line)
    const assistantIdx = findNextAssistantLine(nextIdx);
    if (assistantIdx === -1) {
      finishScene();
    } else {
      pushAssistantDialogue(assistantIdx);
      setStepIndex(assistantIdx);
    }
  };

  const findNextAssistantLine = (fromIndex: number): number => {
    for (let i = fromIndex; i < scene.dialogues.length; i++) {
      if (!scene.dialogues[i].isUser) return i;
    }
    return -1;
  };

  const pushReferenceBubble = (line: DialogueLine) => {
    const refBubble: ChatBubble = {
      id: `ref-${Date.now()}`,
      role: 'assistant',
      english: `✅ Reference: "${line.english}"`,
      chinese: `参考回答："${line.chinese}"`,
      timestamp: Date.now(),
      isReference: true,
    };
    setBubbles(prev => [...prev, refBubble]);
    // auto-play reference
    speakText(line.english);
  };

  // ========== Evaluate user answer ==========
  const evaluateAnswer = (input: string, line: DialogueLine) => {
    const inputLower = input.toLowerCase();
    const expectedLower = line.english.toLowerCase();

    // Check keywords first (if defined) — that's our primary signal
    let keywordHit = 0;
    let keywordTotal = 0;
    if (line.keyword && line.keyword.length > 0) {
      keywordTotal = line.keyword.length;
      for (const kw of line.keyword) {
        if (inputLower.includes(kw.toLowerCase())) keywordHit++;
      }
    }

    // Also check similarity with expected line and any alternatives
    const candidates = [line.english, ...(line.alternatives || [])];
    let bestSimilarity = 0;
    let bestMatch: string | null = null;
    for (const c of candidates) {
      const sim = similarity(inputLower, c.toLowerCase());
      if (sim > bestSimilarity) {
        bestSimilarity = sim;
        bestMatch = c;
      }
    }

    // Score composition: 60% keywords, 40% similarity
    const keywordScore = keywordTotal > 0 ? (keywordHit / keywordTotal) * 100 : 50;
    const simScore = bestSimilarity * 100;
    const finalScore = Math.round(keywordScore * 0.6 + simScore * 0.4);

    const isCorrect = finalScore >= 65;

    let feedback = '';
    if (finalScore >= 85) feedback = '🌟 Perfect! Awesome pronunciation!';
    else if (finalScore >= 70) feedback = '👍 Great job! Very good!';
    else if (finalScore >= 50) feedback = '💪 Nice try! Keep going!';
    else feedback = '📝 Don\'t worry, listen and try again!';

    return {
      score: Math.min(100, finalScore),
      isCorrect,
      feedback,
      keywordHit,
      keywordTotal,
      bestSimilarity,
      bestMatch,
    };
  };

  // Simple Levenshtein-based similarity
  const similarity = (a: string, b: string) => {
    // word-level Jaccard for better phrase matching
    const wa = a.split(/[\s,!.?]+/).filter(Boolean);
    const wb = b.split(/[\s,!.?]+/).filter(Boolean);
    if (wa.length === 0 || wb.length === 0) return 0;
    const setA = new Set(wa);
    const setB = new Set(wb);
    let inter = 0;
    for (const x of setA) if (setB.has(x)) inter++;
    const union = setA.size + setB.size - inter;
    return union === 0 ? 0 : inter / union;
  };

  // ========== Scene completion ==========
  const finishScene = () => {
    setCompleted(true);
    if (isAuthenticated && user) {
      const avgScore = turnScores.length > 0 ? Math.round(score / turnScores.length) : 0;
      addExp(Math.round((avgScore / 100) * 40));
      addCoins(Math.round((avgScore / 100) * 20));
      addRecord({
        userId: user.id,
        lessonId: scene.id,
        courseId: 'conversation',
        score: avgScore,
        duration: Math.max(3, Math.round(scene.turns / 2)),
      });
    }

    const completeBubble: ChatBubble = {
      id: 'done',
      role: 'assistant',
      english: '🎉 Great job! You finished the conversation!',
      chinese: '太棒了！你完成了这个对话场景！',
      timestamp: Date.now(),
      isSystem: true,
    };
    setBubbles(prev => [...prev, completeBubble]);
    setIsUserTurn(false);
  };

  // ========== Voice recording ==========
  const toggleRecord = () => {
    if (!recognitionRef.current) {
      // Fallback
      const demoSentences = ['I am Tom', 'My name is Tom', 'Yes I am happy', 'Apple please thank you'];
      const demoInput = demoSentences[Math.floor(Math.random() * demoSentences.length)];
      setIsRecording(true);
      setTimeout(() => {
        setIsRecording(false);
        setUserInput(demoInput);
        setTimeout(() => handleSubmitUserInput(demoInput), 200);
      }, 1500);
      return;
    }
    if (isRecording) {
      recognitionRef.current.stop();
    } else {
      recognitionRef.current.start();
      setIsRecording(true);
    }
  };

  const handleSend = () => {
    if (!userInput.trim()) return;
    handleSubmitUserInput(userInput);
  };

  const restartScene = () => initScene();

  // ========== Render ==========
  if (completed) {
    return <CompletionSummary scene={scene} turnScores={turnScores} correctCount={correctCount} onRestart={restartScene} />;
  }

  const currentLine = scene.dialogues[stepIndex];

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-pink-50 via-rose-50 to-orange-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-16 z-40 border-b-2 border-kids-pink/20">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/conversation" className="flex items-center gap-2 text-gray-500 hover:text-kids-pink text-sm">
            <ArrowLeft size={18} />
            返回场景
          </Link>
          <div className="flex items-center gap-2">
            <div className={`${scene.emojiBg} w-8 h-8 rounded-lg flex items-center justify-center text-lg`}>
              {scene.icon}
            </div>
            <div>
              <h2 className="font-bold text-gray-800 text-sm leading-tight">{scene.title}</h2>
              <p className="text-xs text-gray-400 leading-tight">{scene.characters.assistantEmoji} {scene.characters.assistant} vs {scene.characters.userEmoji} {scene.characters.user}</p>
            </div>
          </div>
          <button
            onClick={restartScene}
            className="p-2 text-gray-400 hover:text-kids-pink hover:bg-kids-pink/5 rounded-lg"
            title="重新开始"
          >
            <RotateCcw size={18} />
          </button>
        </div>
      </header>

      {/* Chat Area */}
      <main ref={chatContainerRef} className="flex-1 overflow-y-auto max-w-4xl w-full mx-auto px-4 py-4 space-y-4">
        {bubbles.map(bubble => (
          <Bubble key={bubble.id} bubble={bubble} showChinese={showChinese} isPlayingAudio={isPlayingAudio} />
        ))}
      </main>

      {/* Current prompt hint */}
      {isUserTurn && currentLine && (
        <div className="max-w-4xl w-full mx-auto px-4 pb-2">
          <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl p-3 flex items-start gap-3">
            <Lightbulb size={18} className="text-amber-500 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-amber-800">
                💡 {currentLine.isPrompt ? '轮到你说啦！请尝试用英语回答' : '请跟我读一遍'}
              </p>
              {showChinese && (
                <p className="text-sm text-amber-700 mt-1">参考中文：{currentLine.chinese}</p>
              )}
              {currentLine.alternatives && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <span className="text-xs text-amber-600">你可以说：</span>
                  {currentLine.alternatives.map((alt, i) => (
                    <button
                      key={i}
                      onClick={() => setUserInput(alt)}
                      className="px-2 py-0.5 bg-white rounded-full text-xs text-amber-700 hover:bg-amber-100 border border-amber-200"
                    >
                      {alt}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Controls Bar */}
      <div className="max-w-4xl w-full mx-auto px-4 pb-3 flex items-center gap-2 text-xs text-gray-500">
        <button
          onClick={() => setShowChinese(v => !v)}
          className={`flex items-center gap-1 px-2 py-1 rounded-lg transition-colors ${showChinese ? 'bg-gray-200 text-gray-700' : 'hover:bg-gray-100'}`}
        >
          {showChinese ? <Eye size={12} /> : <EyeOff size={12} />} 中文
        </button>
        <button
          onClick={() => setShowVocabulary(v => !v)}
          className={`flex items-center gap-1 px-2 py-1 rounded-lg transition-colors ${showVocabulary ? 'bg-gray-200 text-gray-700' : 'hover:bg-gray-100'}`}
        >
          <BookOpen size={12} /> 词汇
        </button>
        <button
          onClick={() => setShowTips(v => !v)}
          className={`flex items-center gap-1 px-2 py-1 rounded-lg transition-colors ${showTips ? 'bg-gray-200 text-gray-700' : 'hover:bg-gray-100'}`}
        >
          <Lightbulb size={12} /> 小贴士
        </button>

        <div className="ml-auto flex items-center gap-1 text-xs">
          <Sparkles size={12} className="text-yellow-500" />
          <span>对话进度 {Math.min(turnScores.length + (isUserTurn ? 1 : 0), scene.dialogues.filter(d => d.isUser).length)}/{scene.dialogues.filter(d => d.isUser).length}</span>
        </div>
      </div>

      {/* Input Area */}
      <div className="bg-white border-t border-gray-100 shadow-lg">
        <div className="max-w-4xl mx-auto px-4 py-3">
          {isUserTurn ? (
            <div className="flex items-center gap-2">
              <button
                onClick={toggleRecord}
                disabled={!isUserTurn}
                className={`flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-md ${
                  isRecording
                    ? 'bg-red-500 animate-pulse'
                    : 'bg-gradient-to-br from-kids-pink to-rose-500 hover:shadow-lg hover:scale-105'
                } text-white disabled:opacity-40`}
                title={isRecording ? '停止录音' : '语音输入'}
              >
                {isRecording ? <Square size={20} fill="white" /> : <Mic size={20} />}
              </button>

              <input
                type="text"
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder={isRecording ? '🎙️ 正在录音...' : '输入你的回答，或点击麦克风说话...'}
                className="flex-1 px-4 py-3 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-kids-pink/50"
                disabled={!isUserTurn}
              />

              <button
                onClick={handleSend}
                disabled={!userInput.trim() || !isUserTurn}
                className="flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center bg-gradient-to-br from-kids-pink to-rose-500 text-white shadow-md hover:shadow-lg hover:scale-105 transition-all disabled:opacity-40 disabled:scale-100"
              >
                <Send size={18} />
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-center py-3 text-gray-400 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-kids-pink rounded-full animate-bounce" />
                {bubbles.length > 0 && !completed ? '等待对方说话...' : '请稍候...'}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Side panels */}
      {showVocabulary && (
        <Panel title="📚 核心词汇" onClose={() => setShowVocabulary(false)}>
          <div className="space-y-2">
            {scene.vocabulary.map((v, i) => (
              <div key={i} className="p-2.5 bg-white rounded-xl border border-gray-100 flex items-center justify-between">
                <div>
                  <div className="text-sm font-semibold text-gray-800">{v.english}</div>
                  <div className="text-xs text-gray-500">{v.chinese}</div>
                </div>
                <button
                  onClick={() => speakText(v.english)}
                  className="p-1.5 text-kids-pink hover:bg-kids-pink/10 rounded-lg"
                >
                  <Volume2 size={16} />
                </button>
              </div>
            ))}
          </div>
        </Panel>
      )}

      {showTips && (
        <Panel title="💡 学习小贴士" onClose={() => setShowTips(false)}>
          <ul className="space-y-2">
            {scene.tips.map((tip, i) => (
              <li key={i} className="p-3 bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl text-sm text-gray-700">
                {tip}
              </li>
            ))}
          </ul>
        </Panel>
      )}
    </div>
  );
}

// ========== Chat Bubble Component ==========
function Bubble({ bubble, showChinese, isPlayingAudio }: { bubble: ChatBubble; showChinese: boolean; isPlayingAudio: boolean }) {
  const isUser = bubble.role === 'user';
  const isSystem = bubble.isSystem;
  const isRef = bubble.isReference;

  if (isSystem) {
    return (
      <div className="flex justify-center my-2">
        <div className="px-4 py-2 bg-gray-100 rounded-full text-xs text-gray-500 max-w-md text-center">
          {bubble.english}
        </div>
      </div>
    );
  }

  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
      {/* Avatar */}
      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0 ${
        isUser ? 'bg-gradient-to-br from-blue-400 to-indigo-500 text-white' : 'bg-gradient-to-br from-pink-400 to-rose-500 text-white'
      }`}>
        {isUser ? '🧒' : (isRef ? '📖' : '👧')}
      </div>

      {/* Bubble content */}
      <div className={`max-w-[80%] ${isUser ? 'items-end' : 'items-start'} flex flex-col`}>
        <div className={`rounded-2xl px-4 py-3 shadow-sm ${
          isRef
            ? 'bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-dashed border-amber-300'
            : isUser
              ? bubble.isUserAttempt && bubble.score && bubble.score < 60
                ? 'bg-gradient-to-br from-rose-50 to-pink-50 border-2 border-rose-200'
                : bubble.isUserAttempt
                  ? 'bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200'
                  : 'bg-gradient-to-br from-blue-400 to-indigo-500 text-white'
              : 'bg-white border border-gray-100'
        }`}>
          <p className={`text-base leading-relaxed ${isUser && !bubble.isUserAttempt ? 'text-white' : ''}`}>
            {bubble.english}
          </p>
          {showChinese && bubble.chinese && (
            <p className={`text-xs mt-1 ${isUser && !bubble.isUserAttempt ? 'text-white/80' : 'text-gray-500'}`}>
              {bubble.chinese}
            </p>
          )}
          {bubble.isUserAttempt && (
            <div className="mt-2 flex items-center gap-2">
              <button
                onClick={() => {
                  if ('speechSynthesis' in window) {
                    window.speechSynthesis.cancel();
                    const u = new SpeechSynthesisUtterance(bubble.english);
                    u.lang = 'en-US';
                    u.rate = 0.8;
                    window.speechSynthesis.speak(u);
                  }
                }}
                className="text-xs flex items-center gap-1 px-2 py-1 rounded-full bg-white shadow-sm hover:bg-gray-50"
              >
                <Volume2 size={12} /> 朗读
              </button>
            </div>
          )}
        </div>

        {/* Feedback pill (on user attempt) */}
        {bubble.isUserAttempt && typeof bubble.score === 'number' && (
          <div className={`mt-1.5 flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium ${
            bubble.score >= 75 ? 'bg-green-50 text-green-700' :
            bubble.score >= 55 ? 'bg-amber-50 text-amber-700' :
            'bg-rose-50 text-rose-700'
          }`}>
            {bubble.score >= 75 ? <CheckCircle size={12} /> :
             bubble.score >= 55 ? <Star size={12} /> :
             <AlertCircle size={12} />}
            <span>
              {bubble.score >= 75 ? 'Excellent!' :
               bubble.score >= 55 ? 'Good try (' + bubble.score + '%)' :
               bubble.feedback || bubble.score + '%'}
            </span>
          </div>
        )}

        {/* Reference audio play */}
        {!isUser && !isRef && bubble.id && (
          <button
            onClick={() => {
              if ('speechSynthesis' in window) {
                window.speechSynthesis.cancel();
                const u = new SpeechSynthesisUtterance(bubble.english);
                u.lang = 'en-US';
                u.rate = 0.8;
                window.speechSynthesis.speak(u);
              }
            }}
            disabled={isPlayingAudio}
            className="mt-1 text-xs text-kids-pink hover:text-kids-pink/80 flex items-center gap-1 disabled:opacity-50"
          >
            <Play size={11} fill="currentColor" /> 重听
          </button>
        )}
      </div>
    </div>
  );
}

// ========== Slide Panel (vocab / tips) ==========
function Panel({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-y-0 right-0 w-full max-w-sm bg-white shadow-2xl z-50 overflow-y-auto animate-slide-in">
      <div className="sticky top-0 bg-white border-b px-5 py-4 flex items-center justify-between">
        <h3 className="font-bold text-gray-800">{title}</h3>
        <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg">✕</button>
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

// ========== Completion Summary ==========
function CompletionSummary({
  scene, turnScores, correctCount, onRestart,
}: {
  scene: typeof conversationScenes[0];
  turnScores: number[];
  correctCount: number;
  onRestart: () => void;
}) {
  const totalTurns = scene.dialogues.filter(d => d.isUser).length;
  const avgScore = turnScores.length > 0 ? Math.round(turnScores.reduce((a, b) => a + b, 0) / turnScores.length) : 0;
  const maxScore = Math.max(...turnScores, 0);
  const minScore = Math.min(...turnScores, 0);

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-yellow-50 via-orange-50 to-rose-50 flex items-center justify-center p-6">
      <div className="max-w-lg w-full bg-white rounded-3xl shadow-2xl p-8 text-center">
        <div className="text-7xl mb-4">🏆</div>
        <h1 className="text-3xl font-bold text-gray-800 mb-2">太棒了！</h1>
        <p className="text-gray-500 mb-6">你完成了《{scene.title}》对话</p>

        {/* Score ring */}
        <div className="relative w-40 h-40 mx-auto mb-6">
          <svg viewBox="0 0 100 100" className="w-full h-full">
            <circle cx="50" cy="50" r="45" fill="none" stroke="#F3F4F6" strokeWidth="8" />
            <circle
              cx="50" cy="50" r="45" fill="none"
              stroke={avgScore >= 75 ? '#22C55E' : avgScore >= 55 ? '#F59E0B' : '#EF4444'}
              strokeWidth="8" strokeLinecap="round"
              strokeDasharray={`${(avgScore / 100) * 283} 283`}
              transform="rotate(-90 50 50)"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-4xl font-bold text-gray-800">{avgScore}</span>
            <span className="text-xs text-gray-400">平均分</span>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="p-3 bg-green-50 rounded-xl">
            <div className="text-green-600 font-bold text-xl">{correctCount}/{totalTurns}</div>
            <div className="text-xs text-gray-500">答对轮次</div>
          </div>
          <div className="p-3 bg-amber-50 rounded-xl">
            <div className="text-amber-600 font-bold text-xl">{maxScore}</div>
            <div className="text-xs text-gray-500">最高分</div>
          </div>
          <div className="p-3 bg-rose-50 rounded-xl">
            <div className="text-rose-600 font-bold text-xl">{minScore}</div>
            <div className="text-xs text-gray-500">最低分</div>
          </div>
        </div>

        {/* Rewards */}
        <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-2xl p-4 mb-6 border border-yellow-100">
          <div className="flex items-center justify-center gap-2 text-sm text-orange-700 mb-2">
            <Sparkles size={16} /> 恭喜获得奖励！
          </div>
          <div className="flex items-center justify-center gap-4">
            <span className="text-sm text-purple-600">⭐ +{Math.round((avgScore / 100) * 40)} EXP</span>
            <span className="text-sm text-yellow-600">🪙 +{Math.round((avgScore / 100) * 20)} 金币</span>
          </div>
        </div>

        {/* Buttons */}
        <div className="space-y-3">
          <button
            onClick={onRestart}
            className="w-full py-3 bg-gradient-to-r from-kids-pink to-rose-500 text-white font-bold rounded-xl hover:shadow-lg transition-all flex items-center justify-center gap-2"
          >
            <RotateCcw size={18} /> 再练一次
          </button>
          <Link
            to="/conversation"
            className="w-full py-3 bg-gray-100 text-gray-700 font-bold rounded-xl hover:bg-gray-200 transition-all block text-center"
          >
            选择下一个场景 →
          </Link>
        </div>

        {/* Rating */}
        <div className="flex justify-center gap-1 mt-6">
          {[1, 2, 3, 4, 5].map(i => (
            <Star
              key={i}
              size={22}
              className={`${i <= Math.round(avgScore / 20) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200'}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
