import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Mail, Calendar, Star, Zap, Flame, Award, Edit2, Save, LogOut, Volume2, RotateCcw } from 'lucide-react';
import { useAuthStore } from '@/stores/authStore';
import { useLearningStore } from '@/stores/learningStore';
import { mockBadges } from '@/data/mockData';
import { formatDate, gradeMap, expToNextLevel } from '@/utils';

const avatarOptions = ['🐼', '🐨', '🦁', '🐯', '🐸', '🐵', '🦊', '🐰', '🐶', '🐱', '🐨', '🐻'];

export default function Profile() {
  const { user, isAuthenticated, logout, updateUser } = useAuthStore();
  const { getCourseProgress, getMasteredWords } = useLearningStore();
  const navigate = useNavigate();
  
  const [isEditing, setIsEditing] = useState(false);
  const [editUsername, setEditUsername] = useState(user?.username || '');
  const [editAvatar, setEditAvatar] = useState(user?.avatar || '🐼');

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🔒</div>
          <h2 className="text-xl font-bold mb-2">请先登录</h2>
          <button onClick={() => navigate('/login')} className="text-kids-blue hover:underline">去登录 →</button>
        </div>
      </div>
    );
  }

  const levelInfo = expToNextLevel(user.exp);
  const masteredWords = getMasteredWords();

  const handleSave = () => {
    if (editUsername.trim()) {
      updateUser({ username: editUsername.trim(), avatar: editAvatar });
    }
    setIsEditing(false);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="bg-gradient-to-br from-kids-blue via-kids-purple to-kids-pink rounded-3xl p-8 text-white mb-8 shadow-xl relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          {['⭐', '🌟', '✨', '🎈', '🎨'].map((e, i) => (
            <span key={i} className="absolute text-4xl" style={{ top: `${5 + i * 15}%`, left: `${70 - i * 10}%` }}>
              {e}
            </span>
          ))}
        </div>

        <div className="relative flex flex-col md:flex-row items-center gap-6">
          {/* Avatar */}
          <div className="relative">
            {isEditing ? (
              <div className="w-32 h-32 bg-white/20 backdrop-blur-sm rounded-3xl p-2">
                <div className="grid grid-cols-4 gap-1">
                  {avatarOptions.map(avatar => (
                    <button
                      key={avatar}
                      onClick={() => setEditAvatar(avatar)}
                      className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl transition-all ${
                        editAvatar === avatar ? 'bg-white scale-110 shadow-lg' : 'bg-white/20 hover:bg-white/40'
                      }`}
                    >
                      {avatar}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="w-28 h-28 bg-white/20 backdrop-blur-sm rounded-3xl flex items-center justify-center text-7xl">
                {user.avatar}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex-1 text-center md:text-left">
            {isEditing ? (
              <input
                type="text"
                value={editUsername}
                onChange={(e) => setEditUsername(e.target.value)}
                className="w-full md:w-64 px-3 py-2 bg-white/20 rounded-xl text-2xl font-bold text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-white/50 text-center md:text-left"
              />
            ) : (
              <h1 className="text-3xl font-bold mb-2">{user.username}</h1>
            )}
            
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 text-sm text-white/80">
              <span className="flex items-center gap-1">
                <Mail size={14} /> {user.email}
              </span>
              <span>•</span>
              <span>{gradeMap[user.grade]}</span>
              <span>•</span>
              <span className="px-2 py-0.5 bg-yellow-400 text-yellow-900 rounded-full text-xs font-bold">
                Level {user.level}
              </span>
            </div>

            {/* Level Progress */}
            <div className="mt-4 max-w-md">
              <div className="flex justify-between text-sm mb-1 text-white/80">
                <span>升级进度</span>
                <span>{levelInfo.current}/{levelInfo.next} EXP</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-yellow-400 rounded-full transition-all duration-500"
                  style={{ width: `${levelInfo.progress}%` }}
                />
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-2">
            {isEditing ? (
              <>
                <button
                  onClick={handleSave}
                  className="px-5 py-2 bg-white text-kids-blue font-semibold rounded-xl hover:shadow-lg transition-all flex items-center gap-2 justify-center"
                >
                  <Save size={16} /> 保存
                </button>
                <button
                  onClick={() => { setIsEditing(false); setEditUsername(user.username); setEditAvatar(user.avatar); }}
                  className="px-5 py-2 bg-white/20 text-white font-medium rounded-xl hover:bg-white/30 transition-all"
                >
                  取消
                </button>
              </>
            ) : (
              <button
                onClick={() => { setIsEditing(true); setEditUsername(user.username); setEditAvatar(user.avatar); }}
                className="px-5 py-2 bg-white text-kids-blue font-semibold rounded-xl hover:shadow-lg transition-all flex items-center gap-2"
              >
                <Edit2 size={16} /> 编辑资料
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { icon: Star, value: user.exp, label: '经验值', color: 'from-yellow-400 to-orange-500' },
          { icon: Zap, value: user.coins, label: '金币', color: 'from-amber-400 to-yellow-500' },
          { icon: Flame, value: user.streakDays + '天', label: '连续打卡', color: 'from-orange-400 to-red-500' },
          { icon: Volume2, value: masteredWords, label: '掌握单词', color: 'from-green-400 to-emerald-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-white rounded-2xl shadow-sm p-5 text-center card-hover">
            <div className={`w-12 h-12 mx-auto mb-3 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center`}>
              <stat.icon size={24} className="text-white" />
            </div>
            <div className="text-2xl font-bold text-gray-800">{stat.value}</div>
            <div className="text-sm text-gray-500">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Account Info */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
            <User className="text-kids-blue" size={20} />
            账户信息
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between py-2 border-b border-gray-100">
              <span className="text-gray-500 text-sm">注册时间</span>
              <span className="text-gray-800 font-medium text-sm flex items-center gap-1">
                <Calendar size={14} /> {formatDate(user.joinedAt)}
              </span>
            </div>
            <div className="flex justify-between py-2 border-b border-gray-100">
              <span className="text-gray-500 text-sm">当前等级</span>
              <span className="text-gray-800 font-medium text-sm">Level {user.level}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-gray-100">
              <span className="text-gray-500 text-sm">学习年级</span>
              <span className="text-gray-800 font-medium text-sm">{gradeMap[user.grade]}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-gray-100">
              <span className="text-gray-500 text-sm">累计课程进度</span>
              <span className="text-gray-800 font-medium text-sm">
                {getCourseProgress('course-1', 24) + getCourseProgress('course-2', 32) + getCourseProgress('course-3', 40) + getCourseProgress('course-4', 48)}%
              </span>
            </div>
          </div>
        </div>

        {/* Badges */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Award className="text-yellow-500" size={20} />
            成就徽章 ({Math.min(user.level + 2, mockBadges.length)}/{mockBadges.length})
          </h3>
          <div className="grid grid-cols-5 gap-2">
            {mockBadges.map((badge, i) => {
              const unlocked = i < user.level + 2;
              return (
                <div
                  key={badge.id}
                  className={`aspect-square rounded-xl p-2 flex flex-col items-center justify-center text-center transition-all ${
                    unlocked 
                      ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border border-yellow-200 hover:scale-105 cursor-default' 
                      : 'bg-gray-50 grayscale opacity-50'
                  }`}
                  title={badge.name + ': ' + badge.description}
                >
                  <span className="text-2xl mb-0.5">{badge.icon}</span>
                  {unlocked && <span className="text-[8px] text-gray-500 leading-tight">{badge.name}</span>}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="mt-8 flex flex-col sm:flex-row gap-4">
        <button
          onClick={() => navigate('/dashboard')}
          className="flex-1 py-3 bg-gradient-to-r from-kids-blue to-kids-purple text-white font-semibold rounded-xl hover:shadow-lg transition-all"
        >
          返回学习中心
        </button>
        <button
          onClick={() => {
            if (confirm('确定要退出登录吗？')) handleLogout();
          }}
          className="flex items-center justify-center gap-2 px-6 py-3 bg-white text-red-500 font-semibold rounded-xl border-2 border-red-100 hover:bg-red-50 transition-all"
        >
          <LogOut size={18} /> 退出登录
        </button>
      </div>
    </div>
  );
}
