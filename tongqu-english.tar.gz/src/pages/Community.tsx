import { useState } from 'react';
import { MessageCircle, Heart, Send, Plus, Search, Tag, Clock, User } from 'lucide-react';
import { useCommunityStore } from '@/stores/communityStore';
import { useAuthStore } from '@/stores/authStore';
import { formatTime } from '@/utils';

export default function Community() {
  const { posts, likePost, addComment, addPost } = useCommunityStore();
  const { user, isAuthenticated } = useAuthStore();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [showPostForm, setShowPostForm] = useState(false);
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostContent, setNewPostContent] = useState('');
  const [selectedPost, setSelectedPost] = useState<string | null>(null);
  const [newComment, setNewComment] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  const allTags = ['学习方法', '家长分享', '资源分享', '打卡', '激励', '老师答疑', '动画片', '语法', '单词'];

  const filteredPosts = posts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          post.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTags = selectedTags.length === 0 || 
                        selectedTags.some(tag => post.tags.includes(tag));
    return matchesSearch && matchesTags;
  });

  const handleSubmitPost = () => {
    if (!user || !newPostTitle.trim() || !newPostContent.trim()) return;
    addPost(user.id, user.username, user.avatar, newPostTitle, newPostContent, selectedTags);
    setNewPostTitle('');
    setNewPostContent('');
    setSelectedTags([]);
    setShowPostForm(false);
  };

  const handleSubmitComment = (postId: string) => {
    if (!user || !newComment.trim()) return;
    addComment(postId, user.id, user.username, user.avatar, newComment);
    setNewComment('');
  };

  const toggleTag = (tag: string) => {
    setSelectedTags(prev => 
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
            <span className="text-3xl">💬</span>
            家长社区
          </h1>
          <p className="text-gray-500 mt-1">交流学习心得，分享教育经验</p>
        </div>
        {isAuthenticated && (
          <button
            onClick={() => setShowPostForm(!showPostForm)}
            className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-kids-blue to-kids-purple text-white font-semibold rounded-xl hover:shadow-lg transition-all"
          >
            <Plus size={18} /> 发帖
          </button>
        )}
      </div>

      {/* New Post Form */}
      {showPostForm && isAuthenticated && (
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6 border-2 border-kids-blue/20">
          <h3 className="font-bold text-gray-800 mb-4">✍️ 发布新帖</h3>
          <input
            type="text"
            value={newPostTitle}
            onChange={(e) => setNewPostTitle(e.target.value)}
            placeholder="标题（简单描述你想分享的内容）"
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-kids-blue/50 mb-3"
          />
          <textarea
            value={newPostContent}
            onChange={(e) => setNewPostContent(e.target.value)}
            placeholder="分享你的想法、经验或问题..."
            rows={4}
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-kids-blue/50 resize-none mb-3"
          />
          
          <div className="mb-4">
            <p className="text-sm text-gray-500 mb-2">添加标签：</p>
            <div className="flex flex-wrap gap-2">
              {allTags.map(tag => (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className={`px-3 py-1.5 rounded-full text-sm transition-all ${
                    selectedTags.includes(tag)
                      ? 'bg-kids-blue text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <Tag size={12} className="inline mr-1" />{tag}
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-3 justify-end">
            <button
              onClick={() => setShowPostForm(false)}
              className="px-5 py-2.5 bg-gray-100 text-gray-600 font-medium rounded-xl hover:bg-gray-200 transition-colors"
            >
              取消
            </button>
            <button
              onClick={handleSubmitPost}
              disabled={!newPostTitle.trim() || !newPostContent.trim()}
              className="px-5 py-2.5 bg-gradient-to-r from-kids-blue to-kids-purple text-white font-medium rounded-xl hover:shadow-lg transition-all disabled:opacity-50"
            >
              发布
            </button>
          </div>
        </div>
      )}

      {/* Search and Tags Filter */}
      <div className="bg-white rounded-2xl shadow-sm p-5 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索帖子..."
              className="w-full pl-12 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-kids-blue/50"
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mt-4">
          {allTags.map(tag => (
            <button
              key={tag}
              onClick={() => toggleTag(tag)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                selectedTags.includes(tag)
                  ? 'bg-kids-blue text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              #{tag}
            </button>
          ))}
        </div>
      </div>

      {/* Hot Topics */}
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-5 mb-6 border border-amber-100">
        <h3 className="font-bold text-amber-700 mb-3 flex items-center gap-2">🔥 热门话题</h3>
        <div className="flex flex-wrap gap-2">
          {['#小学英语启蒙', '#背单词方法', '#口语练习技巧', '#小升初英语', '#家长经验分享', '#英语动画推荐'].map(topic => (
            <span key={topic} className="px-3 py-1.5 bg-white rounded-full text-sm text-gray-600 hover:text-kids-blue hover:bg-kids-blue/10 cursor-pointer transition-all">
              {topic}
            </span>
          ))}
        </div>
      </div>

      {/* Posts List */}
      <div className="space-y-4">
        {filteredPosts.map(post => {
          const isExpanded = selectedPost === post.id;
          return (
            <div key={post.id} className="bg-white rounded-2xl shadow-sm overflow-hidden">
              {/* Post Header */}
              <div className="p-5">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-kids-blue to-kids-purple rounded-full flex items-center justify-center text-2xl flex-shrink-0">
                    {post.avatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-gray-800">{post.username}</span>
                      <span className="text-xs text-gray-400">·</span>
                      <span className="text-xs text-gray-400 flex items-center gap-1">
                        <Clock size={12} /> {formatTime(post.createdAt)}
                      </span>
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2 text-lg">{post.title}</h3>
                    <p className="text-gray-600 text-sm whitespace-pre-wrap leading-relaxed line-clamp-3">
                      {post.content}
                    </p>
                    
                    {post.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 mt-3">
                        {post.tags.map(tag => (
                          <span key={tag} className="px-2 py-0.5 bg-blue-50 text-kids-blue text-xs rounded-full">
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex items-center gap-5 mt-4 pt-3 border-t">
                      <button 
                        onClick={() => likePost(post.id)}
                        className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-red-500 transition-colors"
                      >
                        <Heart size={16} className="hover:fill-red-500" />
                        <span>{post.likes}</span>
                      </button>
                      <button 
                        onClick={() => setSelectedPost(isExpanded ? null : post.id)}
                        className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-kids-blue transition-colors"
                      >
                        <MessageCircle size={16} />
                        <span>{post.comments.length} 评论</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Comments Section */}
              {isExpanded && (
                <div className="bg-gray-50 px-5 py-4 border-t">
                  {/* Comments */}
                  {post.comments.length > 0 && (
                    <div className="space-y-3 mb-4">
                      {post.comments.map(comment => (
                        <div key={comment.id} className="flex items-start gap-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-gray-200 to-gray-300 rounded-full flex items-center justify-center text-lg flex-shrink-0">
                            {comment.avatar}
                          </div>
                          <div className="flex-1 bg-white rounded-xl p-3">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-semibold text-gray-800">{comment.username}</span>
                              <span className="text-xs text-gray-400">{formatTime(comment.createdAt)}</span>
                            </div>
                            <p className="text-sm text-gray-600">{comment.content}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Add Comment */}
                  {isAuthenticated ? (
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="写下你的评论..."
                        className="flex-1 px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-kids-blue/50"
                        onKeyDown={(e) => e.key === 'Enter' && handleSubmitComment(post.id)}
                      />
                      <button
                        onClick={() => handleSubmitComment(post.id)}
                        disabled={!newComment.trim()}
                        className="px-4 py-2 bg-gradient-to-r from-kids-blue to-kids-purple text-white rounded-xl hover:shadow-md transition-all disabled:opacity-50"
                      >
                        <Send size={16} />
                      </button>
                    </div>
                  ) : (
                    <p className="text-center text-sm text-gray-400 py-2">登录后参与评论互动</p>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {filteredPosts.length === 0 && (
          <div className="text-center py-20 bg-white rounded-2xl">
            <div className="text-6xl mb-4">🤷</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">没有找到相关帖子</h3>
            <p className="text-gray-500">试试调整搜索关键词或筛选标签</p>
          </div>
        )}
      </div>
    </div>
  );
}
