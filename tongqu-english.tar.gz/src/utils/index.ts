// 本地存储工具
export const storage = {
  get<T>(key: string, defaultValue: T): T {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch {
      return defaultValue;
    }
  },
  set<T>(key: string, value: T): void {
    localStorage.setItem(key, JSON.stringify(value));
  },
  remove(key: string): void {
    localStorage.removeItem(key);
  },
};

// 生成唯一ID
export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// 格式化日期
export const formatDate = (date: string | Date): string => {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
};

export const formatTime = (date: string | Date): string => {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleString('zh-CN', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

// 计算两个日期之间的天数
export const daysBetween = (start: string, end: string = new Date().toISOString()): number => {
  const startDate = new Date(start);
  const endDate = new Date(end);
  const diff = endDate.getTime() - startDate.getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24));
};

// 检查是否今天
export const isToday = (dateStr: string): boolean => {
  const date = new Date(dateStr);
  const today = new Date();
  return date.toDateString() === today.toDateString();
};

// 获取今天的日期字符串
export const todayStr = (): string => new Date().toISOString().split('T')[0];

// 根据经验值计算等级
export const expToLevel = (exp: number): number => {
  return Math.floor(exp / 100) + 1;
};

// 获取下一级所需经验
export const expToNextLevel = (exp: number): { current: number; next: number; progress: number } => {
  const currentLevel = expToLevel(exp);
  const currentLevelExp = (currentLevel - 1) * 100;
  const nextLevelExp = currentLevel * 100;
  const progress = ((exp - currentLevelExp) / (nextLevelExp - currentLevelExp)) * 100;
  return { current: exp - currentLevelExp, next: 100, progress };
};

// 口语跟读评分（模拟）
export const calculateSpeakingScore = (accuracy: number, fluency: number, completeness: number): number => {
  return Math.round((accuracy * 0.4 + fluency * 0.35 + completeness * 0.25) * 100);
};

// 随机打乱数组
export const shuffle = <T>(array: T[]): T[] => {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
};

// 播放发音（使用Web Speech API）
export const speak = (text: string, lang: string = 'en-US'): void => {
  if ('speechSynthesis' in window) {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = 0.8;
    utterance.pitch = 1;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  }
};

// 年级映射
export const gradeMap: Record<string, string> = {
  '1': '一年级',
  '2': '二年级',
  '3': '三年级',
  '4': '四年级',
  '5': '五年级',
  '6': '六年级',
};

// 等级中文名称
export const levelNames: Record<string, string> = {
  starter: '启蒙级',
  elementary: '初级',
  intermediate: '中级',
  advanced: '高级',
};
