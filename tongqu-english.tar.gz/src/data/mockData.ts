import type { Course, Word, GrammarQuestion, ListeningQuestion, Post, Badge, LearningPath } from '@/types';

// 分级课程数据
export const mockCourses: Course[] = [
  {
    id: 'course-1',
    title: '快乐启蒙英语',
    description: '适合零基础小朋友，从认识字母、简单单词开始，建立英语学习兴趣。',
    level: 'starter',
    gradeRange: '1-2年级',
    icon: '🌟',
    color: 'kids-yellow',
    totalLessons: 24,
    estimatedHours: 12,
    rating: 4.9,
    studentsCount: 12580,
    lessons: [
      { id: 'lesson-1-1', courseId: 'course-1', title: '字母ABC', order: 1, type: 'vocabulary', duration: 15, isFree: true },
      { id: 'lesson-1-2', courseId: 'course-1', title: '数字1-20', order: 2, type: 'vocabulary', duration: 15, isFree: true },
      { id: 'lesson-1-3', courseId: 'course-1', title: '问候语', order: 3, type: 'speaking', duration: 20, isFree: true },
      { id: 'lesson-1-4', courseId: 'course-1', title: '颜色词汇', order: 4, type: 'vocabulary', duration: 15, isFree: false },
      { id: 'lesson-1-5', courseId: 'course-1', title: '动物世界', order: 5, type: 'listening', duration: 20, isFree: false },
      { id: 'lesson-1-6', courseId: 'course-1', title: '水果家族', order: 6, type: 'vocabulary', duration: 15, isFree: false },
    ],
  },
  {
    id: 'course-2',
    title: '小学英语入门',
    description: '覆盖小学低年级核心词汇和基础语法，培养听说读写能力。',
    level: 'elementary',
    gradeRange: '2-3年级',
    icon: '🌈',
    color: 'kids-pink',
    totalLessons: 32,
    estimatedHours: 20,
    rating: 4.8,
    studentsCount: 18920,
    lessons: [
      { id: 'lesson-2-1', courseId: 'course-2', title: '家庭称谓', order: 1, type: 'vocabulary', duration: 15, isFree: true },
      { id: 'lesson-2-2', courseId: 'course-2', title: 'be动词用法', order: 2, type: 'grammar', duration: 25, isFree: true },
      { id: 'lesson-2-3', courseId: 'course-2', title: '自我介绍', order: 3, type: 'speaking', duration: 20, isFree: true },
      { id: 'lesson-2-4', courseId: 'course-2', title: '学校生活', order: 4, type: 'listening', duration: 20, isFree: false },
      { id: 'lesson-2-5', courseId: 'course-2', title: '一般现在时', order: 5, type: 'grammar', duration: 25, isFree: false },
      { id: 'lesson-2-6', courseId: 'course-2', title: '运动爱好', order: 6, type: 'vocabulary', duration: 15, isFree: false },
    ],
  },
  {
    id: 'course-3',
    title: '进阶英语挑战',
    description: '面向中高年级，深入学习时态、句型，提升阅读理解能力。',
    level: 'intermediate',
    gradeRange: '4-5年级',
    icon: '🚀',
    color: 'kids-purple',
    totalLessons: 40,
    estimatedHours: 30,
    rating: 4.7,
    studentsCount: 9860,
    lessons: [
      { id: 'lesson-3-1', courseId: 'course-3', title: '一般过去时', order: 1, type: 'grammar', duration: 30, isFree: true },
      { id: 'lesson-3-2', courseId: 'course-3', title: '城市与交通', order: 2, type: 'vocabulary', duration: 20, isFree: true },
      { id: 'lesson-3-3', courseId: 'course-3', title: '问路与指路', order: 3, type: 'speaking', duration: 25, isFree: false },
      { id: 'lesson-3-4', courseId: 'course-3', title: '现在进行时', order: 4, type: 'grammar', duration: 30, isFree: false },
      { id: 'lesson-3-5', courseId: 'course-3', title: '天气预报', order: 5, type: 'listening', duration: 25, isFree: false },
      { id: 'lesson-3-6', courseId: 'course-3', title: '比较级与最高级', order: 6, type: 'grammar', duration: 30, isFree: false },
    ],
  },
  {
    id: 'course-4',
    title: '小升初冲刺',
    description: '系统梳理小学英语全部知识点，高效备战小升初考试。',
    level: 'advanced',
    gradeRange: '5-6年级',
    icon: '🏆',
    color: 'kids-blue',
    totalLessons: 48,
    estimatedHours: 40,
    rating: 4.9,
    studentsCount: 15240,
    lessons: [
      { id: 'lesson-4-1', courseId: 'course-4', title: '时态大总结', order: 1, type: 'grammar', duration: 35, isFree: true },
      { id: 'lesson-4-2', courseId: 'course-4', title: '完形填空技巧', order: 2, type: 'listening', duration: 30, isFree: true },
      { id: 'lesson-4-3', courseId: 'course-4', title: '阅读理解训练', order: 3, type: 'grammar', duration: 35, isFree: false },
      { id: 'lesson-4-4', courseId: 'course-4', title: '写作入门', order: 4, type: 'speaking', duration: 30, isFree: false },
      { id: 'lesson-4-5', courseId: 'course-4', title: '综合语法', order: 5, type: 'grammar', duration: 35, isFree: false },
      { id: 'lesson-4-6', courseId: 'course-4', title: '模拟测试', order: 6, type: 'listening', duration: 40, isFree: false },
    ],
  },
];

// 单词数据
export const mockWords: Record<string, Word[]> = {
  'lesson-1-1': [
    { id: 'w-1', english: 'Apple', chinese: '苹果', phonetic: '/ˈæp.əl/', example: 'I like apples.', exampleTranslation: '我喜欢苹果。', courseId: 'course-1', lessonId: 'lesson-1-1' },
    { id: 'w-2', english: 'Banana', chinese: '香蕉', phonetic: '/bəˈnæn.ə/', example: 'Monkeys eat bananas.', exampleTranslation: '猴子吃香蕉。', courseId: 'course-1', lessonId: 'lesson-1-1' },
    { id: 'w-3', english: 'Cat', chinese: '猫', phonetic: '/kæt/', example: 'The cat is cute.', exampleTranslation: '这只猫很可爱。', courseId: 'course-1', lessonId: 'lesson-1-1' },
    { id: 'w-4', english: 'Dog', chinese: '狗', phonetic: '/dɒɡ/', example: 'I have a dog.', exampleTranslation: '我有一只狗。', courseId: 'course-1', lessonId: 'lesson-1-1' },
    { id: 'w-5', english: 'Elephant', chinese: '大象', phonetic: '/ˈel.ɪ.fənt/', example: 'Elephants are big.', exampleTranslation: '大象很大。', courseId: 'course-1', lessonId: 'lesson-1-1' },
    { id: 'w-6', english: 'Fish', chinese: '鱼', phonetic: '/fɪʃ/', example: 'Fish can swim.', exampleTranslation: '鱼会游泳。', courseId: 'course-1', lessonId: 'lesson-1-1' },
  ],
  'lesson-1-2': [
    { id: 'w-7', english: 'One', chinese: '一', phonetic: '/wʌn/', example: 'I have one book.', exampleTranslation: '我有一本书。', courseId: 'course-1', lessonId: 'lesson-1-2' },
    { id: 'w-8', english: 'Two', chinese: '二', phonetic: '/tuː/', example: 'Two birds are flying.', exampleTranslation: '两只鸟在飞。', courseId: 'course-1', lessonId: 'lesson-1-2' },
    { id: 'w-9', english: 'Three', chinese: '三', phonetic: '/θriː/', example: 'Three little pigs.', exampleTranslation: '三只小猪。', courseId: 'course-1', lessonId: 'lesson-1-2' },
    { id: 'w-10', english: 'Four', chinese: '四', phonetic: '/fɔːr/', example: 'I have four pencils.', exampleTranslation: '我有四支铅笔。', courseId: 'course-1', lessonId: 'lesson-1-2' },
    { id: 'w-11', english: 'Five', chinese: '五', phonetic: '/faɪv/', example: 'Five fingers on a hand.', exampleTranslation: '一只手有五根手指。', courseId: 'course-1', lessonId: 'lesson-1-2' },
    { id: 'w-12', english: 'Ten', chinese: '十', phonetic: '/ten/', example: 'Ten little toes.', exampleTranslation: '十个小脚趾。', courseId: 'course-1', lessonId: 'lesson-1-2' },
  ],
  'lesson-1-3': [
    { id: 'w-13', english: 'Hello', chinese: '你好', phonetic: '/həˈloʊ/', example: 'Hello, how are you?', exampleTranslation: '你好，你好吗？', courseId: 'course-1', lessonId: 'lesson-1-3' },
    { id: 'w-14', english: 'Goodbye', chinese: '再见', phonetic: '/ɡʊdˈbaɪ/', example: 'Goodbye, see you tomorrow!', exampleTranslation: '再见，明天见！', courseId: 'course-1', lessonId: 'lesson-1-3' },
    { id: 'w-15', english: 'Thank you', chinese: '谢谢', phonetic: '/ˈθæŋkjuː/', example: 'Thank you for your help.', exampleTranslation: '谢谢你的帮助。', courseId: 'course-1', lessonId: 'lesson-1-3' },
    { id: 'w-16', english: 'Please', chinese: '请', phonetic: '/pliːz/', example: 'Please sit down.', exampleTranslation: '请坐。', courseId: 'course-1', lessonId: 'lesson-1-3' },
    { id: 'w-17', english: 'Sorry', chinese: '对不起', phonetic: '/ˈsɒr.i/', example: "I'm sorry I'm late.", exampleTranslation: '对不起，我迟到了。', courseId: 'course-1', lessonId: 'lesson-1-3' },
    { id: 'w-18', english: 'Welcome', chinese: '欢迎', phonetic: '/ˈwel.kəm/', example: 'Welcome to my home!', exampleTranslation: '欢迎来我家！', courseId: 'course-1', lessonId: 'lesson-1-3' },
  ],
  'lesson-2-1': [
    { id: 'w-19', english: 'Father', chinese: '父亲', phonetic: '/ˈfɑː.ðər/', example: 'My father is a doctor.', exampleTranslation: '我的父亲是医生。', courseId: 'course-2', lessonId: 'lesson-2-1' },
    { id: 'w-20', english: 'Mother', chinese: '母亲', phonetic: '/ˈmʌð.ər/', example: 'My mother cooks well.', exampleTranslation: '我妈妈做饭很好吃。', courseId: 'course-2', lessonId: 'lesson-2-1' },
    { id: 'w-21', english: 'Brother', chinese: '兄弟', phonetic: '/ˈbrʌð.ər/', example: 'I have a brother.', exampleTranslation: '我有一个兄弟。', courseId: 'course-2', lessonId: 'lesson-2-1' },
    { id: 'w-22', english: 'Sister', chinese: '姐妹', phonetic: '/ˈsɪs.tər/', example: 'My sister is kind.', exampleTranslation: '我姐姐很善良。', courseId: 'course-2', lessonId: 'lesson-2-1' },
    { id: 'w-23', english: 'Grandpa', chinese: '爷爷/外公', phonetic: '/ˈɡrænpɑː/', example: 'Grandpa tells stories.', exampleTranslation: '爷爷讲故事。', courseId: 'course-2', lessonId: 'lesson-2-1' },
    { id: 'w-24', english: 'Grandma', chinese: '奶奶/外婆', phonetic: '/ˈɡrænmɑː/', example: 'Grandma loves me.', exampleTranslation: '奶奶爱我。', courseId: 'course-2', lessonId: 'lesson-2-1' },
  ],
};

// 语法题数据
export const mockGrammarQuestions: Record<string, GrammarQuestion[]> = {
  'lesson-2-2': [
    { id: 'g-1', lessonId: 'lesson-2-2', question: 'I ___ a student.', options: ['am', 'is', 'are', 'be'], correctAnswer: 0, explanation: '主语是 I，be 动词用 am。' },
    { id: 'g-2', lessonId: 'lesson-2-2', question: 'She ___ my sister.', options: ['am', 'is', 'are', 'be'], correctAnswer: 1, explanation: '主语是 She（第三人称单数），be 动词用 is。' },
    { id: 'g-3', lessonId: 'lesson-2-2', question: 'They ___ good friends.', options: ['am', 'is', 'are', 'be'], correctAnswer: 2, explanation: '主语是 They（复数），be 动词用 are。' },
    { id: 'g-4', lessonId: 'lesson-2-2', question: 'My father ___ a teacher.', options: ['am', 'is', 'are', 'be'], correctAnswer: 1, explanation: '主语 My father 是第三人称单数，be 动词用 is。' },
    { id: 'g-5', lessonId: 'lesson-2-2', question: 'We ___ in the classroom.', options: ['am', 'is', 'are', 'be'], correctAnswer: 2, explanation: '主语是 We（复数），be 动词用 are。' },
  ],
  'lesson-2-5': [
    { id: 'g-6', lessonId: 'lesson-2-5', question: 'He ___ football every day.', options: ['play', 'plays', 'playing', 'played'], correctAnswer: 1, explanation: '主语是第三人称单数，一般现在时动词要加 s。' },
    { id: 'g-7', lessonId: 'lesson-2-5', question: 'She ___ to school by bus.', options: ['go', 'goes', 'going', 'went'], correctAnswer: 1, explanation: '主语是 She，一般现在时动词用 goes。' },
    { id: 'g-8', lessonId: 'lesson-2-5', question: 'They ___ TV in the evening.', options: ['watch', 'watches', 'watching', 'watched'], correctAnswer: 0, explanation: '主语是 They（复数），一般现在时动词不加 s。' },
    { id: 'g-9', lessonId: 'lesson-2-5', question: 'I ___ my homework at home.', options: ['do', 'does', 'doing', 'did'], correctAnswer: 0, explanation: '主语是 I，一般现在时动词用原形。' },
    { id: 'g-10', lessonId: 'lesson-2-5', question: 'Tom ___ ice cream very much.', options: ['like', 'likes', 'liking', 'liked'], correctAnswer: 1, explanation: 'Tom 是第三人称单数，动词用 likes。' },
  ],
  'lesson-3-1': [
    { id: 'g-11', lessonId: 'lesson-3-1', question: 'Yesterday I ___ to the park.', options: ['go', 'goes', 'went', 'going'], correctAnswer: 2, explanation: 'Yesterday 表示过去时间，用一般过去时 went。' },
    { id: 'g-12', lessonId: 'lesson-3-1', question: 'She ___ a new bag last week.', options: ['buy', 'buys', 'bought', 'buying'], correctAnswer: 2, explanation: 'last week 表示过去，用过去式 bought。' },
    { id: 'g-13', lessonId: 'lesson-3-1', question: 'We ___ a movie last night.', options: ['watch', 'watches', 'watched', 'watching'], correctAnswer: 2, explanation: 'last night 表示过去，用过去式 watched。' },
    { id: 'g-14', lessonId: 'lesson-3-1', question: 'He ___ his homework yesterday.', options: ['do', 'does', 'did', 'doing'], correctAnswer: 2, explanation: 'yesterday 表示过去，用过去式 did。' },
    { id: 'g-15', lessonId: 'lesson-3-1', question: 'They ___ to Beijing last year.', options: ['go', 'goes', 'went', 'going'], correctAnswer: 2, explanation: 'last year 表示过去，用过去式 went。' },
  ],
  'lesson-3-6': [
    { id: 'g-16', lessonId: 'lesson-3-6', question: 'Tom is ___ than Jack.', options: ['tall', 'taller', 'tallest', 'more tall'], correctAnswer: 1, explanation: 'than 用于比较级，tall 的比较级是 taller。' },
    { id: 'g-17', lessonId: 'lesson-3-6', question: 'This book is ___ of the three.', options: ['interesting', 'more interesting', 'most interesting', 'the most interesting'], correctAnswer: 3, explanation: 'of the three 表示三者以上，用最高级，注意要加 the。' },
    { id: 'g-18', lessonId: 'lesson-3-6', question: 'My mother is ___ than my father.', options: ['young', 'younger', 'youngest', 'more young'], correctAnswer: 1, explanation: 'than 用于比较级，young 的比较级是 younger。' },
    { id: 'g-19', lessonId: 'lesson-3-6', question: 'Elephants are ___ animals in the world.', options: ['big', 'bigger', 'biggest', 'the biggest'], correctAnswer: 3, explanation: 'in the world 表示范围，用最高级，注意加 the。' },
    { id: 'g-20', lessonId: 'lesson-3-6', question: 'She sings ___ than her sister.', options: ['good', 'better', 'best', 'more good'], correctAnswer: 1, explanation: 'good 的比较级是不规则变化 better。' },
  ],
};

// 听力题数据
export const mockListeningQuestions: Record<string, ListeningQuestion[]> = {
  'lesson-1-5': [
    { id: 'l-1', lessonId: 'lesson-1-5', audioUrl: 'audio-1', question: 'What animal is it?', options: ['Cat', 'Dog', 'Elephant', 'Fish'], correctAnswer: 0, transcript: 'Meow, meow!' },
    { id: 'l-2', lessonId: 'lesson-1-5', audioUrl: 'audio-2', question: 'What animal is it?', options: ['Cat', 'Dog', 'Elephant', 'Bird'], correctAnswer: 1, transcript: 'Woof, woof!' },
    { id: 'l-3', lessonId: 'lesson-1-5', audioUrl: 'audio-3', question: 'What animal is it?', options: ['Fish', 'Bird', 'Dog', 'Monkey'], correctAnswer: 1, transcript: 'Tweet, tweet!' },
    { id: 'l-4', lessonId: 'lesson-1-5', audioUrl: 'audio-4', question: 'How many animals do you hear?', options: ['One', 'Two', 'Three', 'Four'], correctAnswer: 2, transcript: 'Meow, woof, tweet!' },
  ],
  'lesson-2-4': [
    { id: 'l-5', lessonId: 'lesson-2-4', audioUrl: 'audio-5', question: 'What subject does Tom like?', options: ['Math', 'English', 'Chinese', 'Science'], correctAnswer: 1, transcript: 'Tom says, "I like English very much!"' },
    { id: 'l-6', lessonId: 'lesson-2-4', audioUrl: 'audio-6', question: 'How many classes do they have in the morning?', options: ['Two', 'Three', 'Four', 'Five'], correctAnswer: 2, transcript: 'We have Chinese, Math, and English in the morning.' },
    { id: 'l-7', lessonId: 'lesson-2-4', audioUrl: 'audio-7', question: 'Where is the library?', options: ['On the first floor', 'On the second floor', 'In the classroom', 'Near the playground'], correctAnswer: 1, transcript: 'The library is on the second floor.' },
  ],
};

// 社区帖子数据
export const mockPosts: Post[] = [
  {
    id: 'post-1',
    userId: 'user-2',
    username: '小明的妈妈',
    avatar: '👩',
    title: '孩子学英语的好方法分享',
    content: '我家小明以前对英语没什么兴趣，后来我用了每天25分钟的学习法，现在他主动要求学英语了！分享一些经验：\n1. 早上起床后听10分钟英文儿歌\n2. 每天背5个单词，用卡片游戏方式\n3. 周末看一集英文动画片\n坚持了三个月，效果真的很明显！',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    likes: 156,
    comments: [
      { id: 'c-1', userId: 'user-3', username: '豆豆爸爸', avatar: '👨', content: '非常实用的分享！我也试试！', createdAt: new Date(Date.now() - 86400000).toISOString() },
      { id: 'c-2', userId: 'user-4', username: '乐乐妈', avatar: '👩‍🦰', content: '卡片游戏具体怎么玩呀？', createdAt: new Date(Date.now() - 3600000).toISOString() },
    ],
    tags: ['学习方法', '家长分享'],
  },
  {
    id: 'post-2',
    userId: 'user-3',
    username: '英语小达人',
    avatar: '🧑',
    title: '我的连续学习100天打卡！',
    content: '终于连续学习100天啦！🎉 从开始只能说Hello，到现在可以简单对话，感觉自己进步好大！感谢平台，让我爱上了英语学习！大家也要加油哦～',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    likes: 289,
    comments: [
      { id: 'c-3', userId: 'user-5', username: '努力的小白', avatar: '🐰', content: '太厉害了！我要向你学习！', createdAt: new Date(Date.now() - 7200000).toISOString() },
    ],
    tags: ['打卡', '激励'],
  },
  {
    id: 'post-3',
    userId: 'user-4',
    username: '学霸养成记',
    avatar: '🦊',
    title: '推荐几部适合小学生的英文动画片',
    content: '英语启蒙，看动画片是个好办法！推荐几部我家孩子超爱看的：\n1. 《Peppa Pig》小猪佩奇 - 语速慢，词汇简单\n2. 《Bluey》布鲁伊 - 地道澳式英语\n3. 《Paw Patrol》汪汪队 - 动作多，孩子喜欢\n4. 《Sesame Street》芝麻街 - 寓教于乐\n建议家长陪着一起看，效果更好！',
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    likes: 423,
    comments: [],
    tags: ['资源分享', '动画片'],
  },
  {
    id: 'post-4',
    userId: 'user-5',
    username: '热心的老师',
    avatar: '👩‍🏫',
    title: '三年级开始学英语需要注意什么？',
    content: '作为小学英语老师，给家长们一些建议：\n1. 不要逼孩子背单词，先培养兴趣\n2. 多听多说，不要只看读写\n3. 音标很重要，但不要太早教\n4. 创造英语环境，家里贴一些英文标签\n有问题可以在评论区问我～',
    createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
    likes: 567,
    comments: [
      { id: 'c-4', userId: 'user-2', username: '小明的妈妈', avatar: '👩', content: '请问音标什么时候教比较好？', createdAt: new Date(Date.now() - 3600000 * 4).toISOString() },
      { id: 'c-5', userId: 'user-5', username: '热心的老师', avatar: '👩‍🏫', content: '建议四年级下学期或者五年级开始，太早孩子理解不了。', createdAt: new Date(Date.now() - 3600000 * 2).toISOString() },
    ],
    tags: ['老师答疑', '学习建议'],
  },
];

// 成就徽章数据
export const mockBadges: Badge[] = [
  { id: 'badge-1', name: '初学者', description: '完成第一节课程', icon: '🌱', condition: '完成第一课' },
  { id: 'badge-2', name: '坚持3天', description: '连续学习3天', icon: '🔥', condition: '连续学习3天' },
  { id: 'badge-3', name: '坚持7天', description: '连续学习7天', icon: '⭐', condition: '连续学习7天' },
  { id: 'badge-4', name: '单词达人', description: '掌握100个单词', icon: '📚', condition: '掌握100个单词' },
  { id: 'badge-5', name: '听力王', description: '听力练习全对', icon: '🎧', condition: '听力练习满分' },
  { id: 'badge-6', name: '口语新星', description: '口语练习获得90分以上', icon: '🎤', condition: '口语得分≥90' },
  { id: 'badge-7', name: '学霸', description: '完成10节课', icon: '🎓', condition: '完成10节课' },
  { id: 'badge-8', name: '百日坚持', description: '连续学习100天', icon: '👑', condition: '连续学习100天' },
  { id: 'badge-9', name: '社区明星', description: '发布的帖子获得100个赞', icon: '🌟', condition: '帖子获100赞' },
  { id: 'badge-10', name: '金币大亨', description: '累计获得5000金币', icon: '💰', condition: '金币≥5000' },
];

// 学习路径推荐
export const mockLearningPaths: LearningPath[] = [
  { id: 'path-1', title: '快乐启蒙之路', description: '适合刚接触英语的小朋友，趣味性强', targetLevel: 'starter', estimatedWeeks: 8, courses: ['course-1'] },
  { id: 'path-2', title: '稳步提升计划', description: '系统学习小学核心词汇和语法', targetLevel: 'elementary', estimatedWeeks: 12, courses: ['course-1', 'course-2'] },
  { id: 'path-3', title: '全面进阶方案', description: '面向中高年级，提升综合能力', targetLevel: 'intermediate', estimatedWeeks: 16, courses: ['course-2', 'course-3'] },
  { id: 'path-4', title: '小升初冲刺', description: '全面备战，冲击好成绩', targetLevel: 'advanced', estimatedWeeks: 20, courses: ['course-3', 'course-4'] },
];

// 模拟今日学习活动数据
export const generateDailyActivity = () => {
  const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  const data = [];
  for (let i = 6; i >= 0; i--) {
    data.push({
      day: days[new Date(Date.now() - i * 86400000).getDay() === 0 ? 6 : new Date(Date.now() - i * 86400000).getDay() - 1],
      minutes: Math.floor(Math.random() * 60) + 15,
    });
  }
  return data;
};
