import { create } from 'zustand';
import { storage, generateId, formatTime } from '@/utils';
import type { Post, Comment } from '@/types';
import { mockPosts } from '@/data/mockData';

interface CommunityState {
  posts: Post[];
  
  initPosts: () => void;
  addPost: (userId: string, username: string, avatar: string, title: string, content: string, tags: string[]) => void;
  likePost: (postId: string) => void;
  addComment: (postId: string, userId: string, username: string, avatar: string, content: string) => void;
}

export const useCommunityStore = create<CommunityState>((set, get) => ({
  posts: storage.get<Post[]>('posts', []),
  
  initPosts: () => {
    const existing = storage.get<Post[]>('posts', []);
    if (existing.length === 0) {
      storage.set('posts', mockPosts);
      set({ posts: mockPosts });
    } else {
      set({ posts: existing });
    }
  },
  
  addPost: (userId, username, avatar, title, content, tags) => {
    const posts = get().posts;
    const newPost: Post = {
      id: generateId(),
      userId,
      username,
      avatar,
      title,
      content,
      createdAt: new Date().toISOString(),
      likes: 0,
      comments: [],
      tags,
    };
    const updatedPosts = [newPost, ...posts];
    storage.set('posts', updatedPosts);
    set({ posts: updatedPosts });
  },
  
  likePost: (postId) => {
    const posts = get().posts;
    const updatedPosts = posts.map(p => 
      p.id === postId ? { ...p, likes: p.likes + 1 } : p
    );
    storage.set('posts', updatedPosts);
    set({ posts: updatedPosts });
  },
  
  addComment: (postId, userId, username, avatar, content) => {
    const posts = get().posts;
    const newComment: Comment = {
      id: generateId(),
      userId,
      username,
      avatar,
      content,
      createdAt: new Date().toISOString(),
    };
    const updatedPosts = posts.map(p => 
      p.id === postId 
        ? { ...p, comments: [...p.comments, newComment] } 
        : p
    );
    storage.set('posts', updatedPosts);
    set({ posts: updatedPosts });
  },
}));
