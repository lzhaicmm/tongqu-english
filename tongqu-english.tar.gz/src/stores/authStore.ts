import { create } from 'zustand';
import { storage, generateId } from '@/utils';
import type { User } from '@/types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  
  register: (username: string, email: string, password: string, grade: string) => { success: boolean; message: string };
  login: (email: string, password: string) => { success: boolean; message: string };
  logout: () => void;
  updateUser: (data: Partial<User>) => void;
  addExp: (amount: number) => void;
  addCoins: (amount: number) => void;
  updateStreak: () => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: storage.get<User | null>('user', null),
  isAuthenticated: !!storage.get<User | null>('user', null),
  
  register: (username, email, password, grade) => {
    // 检查邮箱是否已注册
    const users = storage.get<User[]>('users', []);
    if (users.find(u => u.email === email)) {
      return { success: false, message: '该邮箱已被注册！' };
    }
    if (users.find(u => u.username === username)) {
      return { success: false, message: '该用户名已被使用！' };
    }
    
    const newUser: User = {
      id: generateId(),
      username,
      email,
      password,
      avatar: ['🐼', '🐨', '🦁', '🐯', '🐸', '🐵', '🦊', '🐰'][Math.floor(Math.random() * 8)],
      grade,
      level: 1,
      exp: 0,
      coins: 0,
      streakDays: 1,
      lastLoginDate: new Date().toISOString(),
      joinedAt: new Date().toISOString(),
    };
    
    users.push(newUser);
    storage.set('users', users);
    storage.set('user', newUser);
    
    set({ user: newUser, isAuthenticated: true });
    return { success: true, message: '注册成功！欢迎加入！' };
  },
  
  login: (email, password) => {
    const users = storage.get<User[]>('users', []);
    const user = users.find(u => u.email === email && u.password === password);
    
    if (!user) {
      return { success: false, message: '邮箱或密码错误！' };
    }
    
    // 更新连续学习天数
    const today = new Date().toDateString();
    const lastLogin = new Date(user.lastLoginDate).toDateString();
    const yesterday = new Date(Date.now() - 86400000).toDateString();
    
    let newStreakDays = user.streakDays;
    if (lastLogin === yesterday) {
      newStreakDays += 1;
    } else if (lastLogin !== today) {
      newStreakDays = 1;
    }
    
    const updatedUser = {
      ...user,
      streakDays: newStreakDays,
      lastLoginDate: new Date().toISOString(),
    };
    
    // 更新users列表
    const updatedUsers = users.map(u => u.id === user.id ? updatedUser : u);
    storage.set('users', updatedUsers);
    storage.set('user', updatedUser);
    
    set({ user: updatedUser, isAuthenticated: true });
    return { success: true, message: '登录成功！' };
  },
  
  logout: () => {
    storage.remove('user');
    set({ user: null, isAuthenticated: false });
  },
  
  updateUser: (data) => {
    const { user } = get();
    if (!user) return;
    const updatedUser = { ...user, ...data };
    storage.set('user', updatedUser);
    
    const users = storage.get<User[]>('users', []);
    const updatedUsers = users.map(u => u.id === user.id ? updatedUser : u);
    storage.set('users', updatedUsers);
    
    set({ user: updatedUser });
  },
  
  addExp: (amount) => {
    const { user, updateUser } = get();
    if (!user) return;
    const newExp = user.exp + amount;
    const newLevel = Math.floor(newExp / 100) + 1;
    updateUser({ exp: newExp, level: newLevel });
  },
  
  addCoins: (amount) => {
    const { user, updateUser } = get();
    if (!user) return;
    updateUser({ coins: user.coins + amount });
  },
  
  updateStreak: () => {
    const { user, updateUser } = get();
    if (!user) return;
    const lastLogin = new Date(user.lastLoginDate).toDateString();
    const yesterday = new Date(Date.now() - 86400000).toDateString();
    
    if (lastLogin === yesterday) {
      updateUser({ streakDays: user.streakDays + 1, lastLoginDate: new Date().toISOString() });
    } else {
      updateUser({ streakDays: 1, lastLoginDate: new Date().toISOString() });
    }
  },
}));
