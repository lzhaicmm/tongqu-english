import { create } from 'zustand';
import { storage, generateId, todayStr } from '@/utils';
import type { LearningRecord, DailyGoal } from '@/types';

interface LearningState {
  records: LearningRecord[];
  dailyGoal: DailyGoal;
  completedLessons: string[];
  
  addRecord: (record: Omit<LearningRecord, 'id' | 'completedAt'>) => void;
  isLessonCompleted: (lessonId: string) => boolean;
  getCourseProgress: (courseId: string, totalLessons: number) => number;
  getTotalStudyMinutes: () => number;
  getTodayStudyMinutes: () => number;
  getWeeklyData: () => { day: string; minutes: number }[];
  getMasteredWords: () => number;
}

export const useLearningStore = create<LearningState>((set, get) => ({
  records: storage.get<LearningRecord[]>('learningRecords', []),
  dailyGoal: storage.get<DailyGoal>('dailyGoal', {
    targetMinutes: 30,
    completedMinutes: 0,
    targetWords: 20,
    completedWords: 0,
    targetStreak: 1,
  }),
  completedLessons: [],
  
  addRecord: (record) => {
    const records = get().records;
    const newRecord: LearningRecord = {
      ...record,
      completedAt: new Date().toISOString(),
    };
    
    // 避免重复记录同一节课
    const existingIndex = records.findIndex(
      r => r.userId === record.userId && r.lessonId === record.lessonId
    );
    
    let updatedRecords: LearningRecord[];
    if (existingIndex >= 0) {
      updatedRecords = records.map((r, i) => 
        i === existingIndex ? newRecord : r
      );
    } else {
      updatedRecords = [...records, newRecord];
    }
    
    storage.set('learningRecords', updatedRecords);
    
    // 更新每日目标
    const today = todayStr();
    const todayRecords = updatedRecords.filter(
      r => r.completedAt.startsWith(today)
    );
    const completedMinutes = todayRecords.reduce((sum, r) => sum + r.duration, 0);
    
    const dailyGoal = {
      ...get().dailyGoal,
      completedMinutes,
      completedWords: get().dailyGoal.completedWords + 6, // 假设每节课6个单词
    };
    storage.set('dailyGoal', dailyGoal);
    
    set({ records: updatedRecords, dailyGoal });
    
    // 更新已完成课时列表
    const completedLessons = [...new Set(updatedRecords.map(r => r.lessonId))];
    set({ completedLessons });
  },
  
  isLessonCompleted: (lessonId) => {
    return get().records.some(r => r.lessonId === lessonId);
  },
  
  getCourseProgress: (courseId, totalLessons) => {
    const completedCount = get().records.filter(r => r.courseId === courseId).length;
    return Math.round((completedCount / totalLessons) * 100);
  },
  
  getTotalStudyMinutes: () => {
    return get().records.reduce((sum, r) => sum + r.duration, 0);
  },
  
  getTodayStudyMinutes: () => {
    const today = todayStr();
    return get().records
      .filter(r => r.completedAt.startsWith(today))
      .reduce((sum, r) => sum + r.duration, 0);
  },
  
  getWeeklyData: () => {
    const days = ['日', '一', '二', '三', '四', '五', '六'];
    const data: { day: string; minutes: number }[] = [];
    const records = get().records;
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(Date.now() - i * 86400000);
      const dateStr = date.toISOString().split('T')[0];
      const dayRecords = records.filter(r => r.completedAt.startsWith(dateStr));
      const minutes = dayRecords.reduce((sum, r) => sum + r.duration, 0);
      data.push({ day: days[date.getDay()], minutes });
    }
    
    return data;
  },
  
  getMasteredWords: () => {
    // 假设每节课平均6个单词
    return get().records.length * 6;
  },
}));
