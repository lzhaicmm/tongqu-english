import { Link, NavLink, useNavigate } from 'react-router-dom';
import { BookOpen, Home, GraduationCap, BarChart3, Users, Trophy, LogOut, User, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { useAuthStore } from '@/stores/authStore';

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuthStore();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { to: '/', icon: Home, label: '首页' },
    { to: '/courses', icon: BookOpen, label: '课程中心' },
    { to: '/dashboard', icon: BarChart3, label: '学习中心' },
    { to: '/community', icon: Users, label: '社区' },
  ];

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50 border-b-4 border-kids-blue">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-gradient-to-br from-kids-blue to-kids-purple rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform shadow-md">
              🎓
            </div>
            <div className="hidden sm:block">
              <span className="text-xl font-bold bg-gradient-to-r from-kids-blue to-kids-purple bg-clip-text text-transparent">
                童趣英语
              </span>
              <p className="text-xs text-gray-400 -mt-1">Kids English Fun</p>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map(item => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-kids-blue/10 text-kids-blue'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                  }`
                }
              >
                <item.icon size={18} />
                {item.label}
              </NavLink>
            ))}
          </div>

          {/* User Area */}
          <div className="flex items-center gap-3">
            {isAuthenticated && user ? (
              <>
                <div className="hidden sm:flex items-center gap-3 text-sm">
                  <div className="flex items-center gap-1 px-2 py-1 bg-yellow-50 rounded-full">
                    <span className="text-yellow-500">🔥</span>
                    <span className="text-orange-600 font-semibold">{user.streakDays}天</span>
                  </div>
                  <div className="flex items-center gap-1 px-2 py-1 bg-blue-50 rounded-full">
                    <span className="text-yellow-500">🪙</span>
                    <span className="text-blue-600 font-semibold">{user.coins}</span>
                  </div>
                </div>
                <Link
                  to="/profile"
                  className="flex items-center gap-2 p-1.5 pr-3 bg-gradient-to-r from-kids-purple/10 to-kids-pink/10 rounded-full hover:shadow-md transition-shadow"
                >
                  <span className="text-2xl">{user.avatar}</span>
                  <div className="hidden sm:block">
                    <p className="text-sm font-medium text-gray-700">{user.username}</p>
                    <p className="text-xs text-gray-400">Lv.{user.level}</p>
                  </div>
                </Link>
                <button
                  onClick={handleLogout}
                  className="hidden md:flex p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                  title="退出登录"
                >
                  <LogOut size={18} />
                </button>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <Link
                  to="/login"
                  className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-kids-blue transition-colors"
                >
                  登录
                </Link>
                <Link
                  to="/register"
                  className="px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-kids-blue to-kids-purple rounded-xl hover:shadow-lg hover:scale-105 transition-all"
                >
                  免费注册
                </Link>
              </div>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-gray-500 hover:bg-gray-100 rounded-lg"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="px-4 py-3 space-y-1">
            {navItems.map(item => (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={() => setMobileMenuOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium ${
                    isActive ? 'bg-kids-blue/10 text-kids-blue' : 'text-gray-600'
                  }`
                }
              >
                <item.icon size={18} />
                {item.label}
              </NavLink>
            ))}
            {isAuthenticated && (
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium text-red-500 w-full"
              >
                <LogOut size={18} />
                退出登录
              </button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
