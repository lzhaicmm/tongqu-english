import { Link } from 'react-router-dom';
import { Heart, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gradient-to-br from-gray-900 to-gray-800 text-white mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-kids-blue to-kids-purple rounded-xl flex items-center justify-center text-2xl">
                🎓
              </div>
              <span className="text-xl font-bold">童趣英语</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-4 max-w-md">
              专为中国小学生打造的在线英语学习平台，通过趣味性强的互动课程、科学的分级体系和个性化学习路径，让孩子快乐学英语，自信说英语！
            </p>
            <div className="flex items-center gap-4">
              <span className="text-gray-500 text-sm">关注我们：</span>
              {['🐦', '📷', '💬', '📺'].map((icon, i) => (
                <button
                  key={i}
                  className="w-9 h-9 bg-gray-700 hover:bg-kids-blue rounded-full flex items-center justify-center transition-colors"
                >
                  {icon}
                </button>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">快速链接</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link to="/courses" className="hover:text-white transition-colors">课程中心</Link></li>
              <li><Link to="/dashboard" className="hover:text-white transition-colors">学习中心</Link></li>
              <li><Link to="/community" className="hover:text-white transition-colors">家长社区</Link></li>
              <li><Link to="/register" className="hover:text-white transition-colors">免费注册</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">联系我们</h3>
            <ul className="space-y-3 text-sm text-gray-400">
              <li className="flex items-center gap-2">
                <Mail size={16} className="text-kids-blue" />
                <span>support@kidsenglish.com</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone size={16} className="text-kids-blue" />
                <span>400-888-9999</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin size={16} className="text-kids-blue mt-0.5" />
                <span>北京市朝阳区科技园</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-sm flex items-center gap-1">
            Made with <Heart size={14} className="text-red-500 fill-red-500" /> for Kids © 2026 童趣英语
          </p>
          <div className="flex gap-4 text-sm text-gray-500">
            <a href="#" className="hover:text-white transition-colors">用户协议</a>
            <a href="#" className="hover:text-white transition-colors">隐私政策</a>
            <a href="#" className="hover:text-white transition-colors">帮助中心</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
