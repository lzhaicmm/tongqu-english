import { createBrowserRouter, Navigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import Courses from '@/pages/Courses';
import CourseDetail from '@/pages/CourseDetail';
import Learning from '@/pages/Learning';
import Dashboard from '@/pages/Dashboard';
import Community from '@/pages/Community';
import Profile from '@/pages/Profile';
import WordGame from '@/pages/learning/WordGame';
import GrammarPractice from '@/pages/learning/GrammarPractice';
import SpeakingPractice from '@/pages/learning/SpeakingPractice';
import ListeningPractice from '@/pages/learning/ListeningPractice';
import SceneSelect from '@/pages/SceneSelect';
import ConversationPractice from '@/pages/ConversationPractice';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      { index: true, element: <Home /> },
      { path: 'login', element: <Login /> },
      { path: 'register', element: <Register /> },
      { path: 'courses', element: <Courses /> },
      { path: 'courses/:id', element: <CourseDetail /> },
      { path: 'learn/:lessonId', element: <Learning /> },
      { path: 'learn/word/:lessonId', element: <WordGame /> },
      { path: 'learn/grammar/:lessonId', element: <GrammarPractice /> },
      { path: 'learn/speaking/:lessonId', element: <SpeakingPractice /> },
      { path: 'learn/listening/:lessonId', element: <ListeningPractice /> },
      { path: 'conversation', element: <SceneSelect /> },
      { path: 'conversation/:sceneId', element: <ConversationPractice /> },
      { path: 'dashboard', element: <Dashboard /> },
      { path: 'community', element: <Community /> },
      { path: 'profile', element: <Profile /> },
      { path: '*', element: <Navigate to="/" replace /> },
    ],
  },
]);

export default router;
