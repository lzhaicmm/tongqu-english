#!/bin/bash
# =======================================================
#  🎓 童趣英语 - 生产构建版本（更快更稳）
# =======================================================
#  说明：先 npm run build，然后用静态服务器托管 dist
#  比 dev server 启动更快、访问更快、不会自动重建
#  适合用完就关的"用一次就好"场景
# =======================================================

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║  🎓 童趣英语 - 生产构建版（更快更稳）     ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"
echo ""

# 检查 Node
if ! command -v node &> /dev/null; then
  echo -e "${RED}❌ 未检测到 Node.js${NC}"
  echo -e "${YELLOW}👉 请先去 https://nodejs.org/zh-cn 安装${NC}"
  read -p "按回车关闭..."
  exit 1
fi

# 依赖
if [ ! -d "node_modules" ]; then
  echo -e "${YELLOW}📦 安装依赖...${NC}"
  npm install --registry https://registry.npmmirror.com
fi

# 构建
if [ ! -d "dist" ] || [ ! -f "dist/index.html" ]; then
  echo -e "${YELLOW}🔨 首次构建 dist...${NC}"
  npm run build
fi

# 清理端口
PORT=3000
if command -v lsof &> /dev/null; then
  OLD_PID=$(lsof -ti :$PORT 2>/dev/null || true)
  if [ -n "$OLD_PID" ]; then
    kill $OLD_PID 2>/dev/null || true
    sleep 1
  fi
fi

echo ""
echo -e "${GREEN}══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}  🚀  启动成功！请打开浏览器访问：${NC}"
echo -e "${GREEN}  ${CYAN}http://localhost:3000${NC}"
echo -e "${GREEN}══════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}🔑  登录账号：demo@kids.com / 123456${NC}"
echo -e "${YELLOW}💡  口语对话：http://localhost:3000/conversation${NC}"
echo ""
echo -e "${YELLOW}⚠️  关闭此终端窗口即可停止服务${NC}"
echo ""

# 用 serve 托管 dist（静态服务器，原生支持 SPA fallback -s）
npx serve dist -l 3000 -s
